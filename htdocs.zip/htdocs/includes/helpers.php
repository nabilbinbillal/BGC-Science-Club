<?php
/**
 * Get the list of unique departments from members table for filtering.
 * Returns an array of distinct department names from the members table,
 * ordered alphabetically.
 *
 * @return array
 */
function getMemberDepartmentsFromDb() {
    global $pdo;
    try {
        $stmt = $pdo->query("SELECT DISTINCT department FROM members WHERE department IS NOT NULL AND department != '' ORDER BY department ASC");
        $departments = $stmt->fetchAll(PDO::FETCH_COLUMN);
        return $departments ?: [];
    } catch (PDOException $e) {
        // Log error or handle as needed
        return [];
    }
}

/**
 * Get the list of unique departments from executives table for filtering.
 * Returns an array of distinct department names from the executives table,
 * ordered alphabetically.
 *
 * @return array
 */
function getExecutiveDepartmentsFromDb() {
    global $pdo;
    try {
        $stmt = $pdo->query("SELECT DISTINCT department FROM executives WHERE department IS NOT NULL AND department != '' ORDER BY department ASC");
        $departments = $stmt->fetchAll(PDO::FETCH_COLUMN);
        return $departments ?: [];
    } catch (PDOException $e) {
        // Log error or handle as needed
        return [];
    }
}
?>
