<?php
// Add reCAPTCHA v3 site key
$recaptcha_site_key = '6LeJSiArAAAAAOqrpowgI-KQ_czZMz76tNFcTiR9'; // Replace with your actual site key

// Handle form submission
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Verify reCAPTCHA v3
    $recaptcha_secret = '6LeJSiArAAAAABMI-lHGQ8Cf-1WblU4AamwgQIxg'; // Replace with your actual secret key
    $recaptcha_response = $_POST['recaptcha_response'];
    
    $verify_url = 'https://www.google.com/recaptcha/api/siteverify';
    $data = [
        'secret' => $recaptcha_secret,
        'response' => $recaptcha_response
    ];
    
    $options = [
        'http' => [
            'header' => "Content-type: application/x-www-form-urlencoded\r\n",
            'method' => 'POST',
            'content' => http_build_query($data)
        ]
    ];
    
    $context = stream_context_create($options);
    $verify_response = file_get_contents($verify_url, false, $context);
    $response_data = json_decode($verify_response);
    
    // Check reCAPTCHA score - 0.0 is very likely a bot, 1.0 is very likely a human
    if (!$response_data->success || $response_data->score < 0.2) {
        $error = "Security verification failed. Please try again.";
    } else {
        $name = sanitize($_POST['name']);
        $department = sanitize($_POST['department']);
        $roll_no = sanitize($_POST['roll_no']);
        $email = sanitize($_POST['email']);
        $phone = sanitize($_POST['phone']);
        $gender = sanitize($_POST['gender']);
        
        // Generate unique member ID
        $member_id = generateMemberId();
        
        // Handle image upload with compression and size check
        $maxFileSize = 10 * 1024 * 1024; // 10 MB in bytes
        $uploadDir = 'uploads/members/';
        
        $image = null;
        if (isset($_FILES['image']) && $_FILES['image']['error'] === 0) {
            if ($_FILES['image']['size'] <= $maxFileSize) {
                $image = uploadMemberImage($_FILES['image'], $uploadDir);
            } else {
                $error = "Profile picture must be less than 10 MB.";
            }
        }
        
        $idCardImage = null;
        if (isset($_FILES['id_card_image']) && $_FILES['id_card_image']['error'] === 0) {
            if ($_FILES['id_card_image']['size'] <= $maxFileSize) {
                $idCardImage = uploadMemberImage($_FILES['id_card_image'], $uploadDir);
            } else {
                $error = "ID card image must be less than 10 MB.";
            }
        }
        
        if (!isset($error)) {
            try {
                $stmt = $pdo->prepare("INSERT INTO members (name, department, roll_no, email, phone, gender, member_id, image, id_card_image, status) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 'pending')");
                $stmt->execute([$name, $department, $roll_no, $email, $phone, $gender, $member_id, $image, $idCardImage]);
                
                $success = true;
                $member_id_display = $member_id;
            } catch (PDOException $e) {
                $error = "An error occurred. Please try again.";
            }
        }
    }
}
?>
<!-- Add reCAPTCHA v3 script -->
<script src="https://www.google.com/recaptcha/api.js?render=<?php echo $recaptcha_site_key; ?>"></script>

<?php if (isset($success) && $success === true): ?>
<!-- Full-screen success message -->
<div class="fixed inset-0 bg-green-500 z-50 flex items-center justify-center">
    <div class="text-center text-white p-8 max-w-lg">
        <svg class="w-20 h-20 mx-auto mb-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"></path>
        </svg>
        <h2 class="text-3xl font-bold mb-4">Application Submitted Successfully!</h2>
        <p class="text-xl mb-4">Your Member ID is: <?php echo $member_id_display; ?></p>
        <p class="mb-2">Please save this ID for future reference.</p>
        <p class="mb-8">Go to the college (Botany Department) or contact any executive to get your membership approved. Thank you for joining BGC Science Club.</p>
        <a href="/" class="bg-white text-green-500 px-6 py-3 rounded-lg font-semibold hover:bg-green-50 transition-colors">
            Return to Home
        </a>
    </div>
</div>

<?php else: ?>
<section class="bg-white dark:bg-gray-800 py-16 transition-colors duration-200">
    <div class="container mx-auto px-4 sm:px-6 lg:px-8">
        <div class="max-w-3xl mx-auto">
            <h1 class="text-3xl font-bold text-center text-gray-900 dark:text-white mb-8">Join BGC Science Club</h1>
            
            <?php if (isset($success)): ?>
            <div class="bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded mb-6">
                <?php echo $success; ?>
            </div>
            <?php endif; ?>
            
            <?php if (isset($error)): ?>
            <div class="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded mb-6">
                <?php echo $error; ?>
            </div>
            <?php endif; ?>
            
            <form method="POST" enctype="multipart/form-data" class="bg-white dark:bg-gray-700 rounded-lg shadow-md p-8" id="joinForm">
                <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div>
                        <label class="block text-gray-700 dark:text-gray-300 text-sm font-bold mb-2" for="name">
                            Full Name *
                        </label>
                        <input type="text" id="name" name="name" required
                            class="form-input w-full px-4 py-2 border rounded-md focus:outline-none focus:ring-2 focus:ring-primary-500 dark:bg-gray-800 dark:border-gray-600 dark:text-white">
                    </div>
                    
                    <div>
                        <label class="block text-gray-700 dark:text-gray-300 text-sm font-bold mb-2" for="department">
                            Department/Class *
                        </label>
                        <select id="department" name="department" required
                            class="form-select w-full px-4 py-2 border rounded-md focus:outline-none focus:ring-2 focus:ring-primary-500 dark:bg-gray-800 dark:border-gray-600 dark:text-white">
                            <option value="">Select Department</option>
                            <?php
                            $departments = getDepartmentOptions();
                            foreach ($departments as $dept) {
                                echo "<option value=\"$dept\">$dept</option>";
                            }
                            ?>
                        </select>
                    </div>
                    
                    <div>
                        <label class="block text-gray-700 dark:text-gray-300 text-sm font-bold mb-2" for="roll_no">
                            Roll Number
                        </label>
                        <input type="text" id="roll_no" name="roll_no"
                            class="form-input w-full px-4 py-2 border rounded-md focus:outline-none focus:ring-2 focus:ring-primary-500 dark:bg-gray-800 dark:border-gray-600 dark:text-white">
                    </div>
                    
                    <div>
                        <label class="block text-gray-700 dark:text-gray-300 text-sm font-bold mb-2" for="email">
                            Email Address *
                        </label>
                        <input type="email" id="email" name="email" required
                            class="form-input w-full px-4 py-2 border rounded-md focus:outline-none focus:ring-2 focus:ring-primary-500 dark:bg-gray-800 dark:border-gray-600 dark:text-white">
                    </div>
                    
                    <div>
                        <label class="block text-gray-700 dark:text-gray-300 text-sm font-bold mb-2" for="phone">
                            Phone Number *
                        </label>
                        <input type="tel" id="phone" name="phone" required
                            class="form-input w-full px-4 py-2 border rounded-md focus:outline-none focus:ring-2 focus:ring-primary-500 dark:bg-gray-800 dark:border-gray-600 dark:text-white">
                    </div>
                    
                    <div>
                        <label class="block text-gray-700 dark:text-gray-300 text-sm font-bold mb-2">
                            Gender *
                        </label>
                        <div class="flex space-x-4">
                            <label class="inline-flex items-center">
                                <input type="radio" name="gender" value="male" checked
                                    class="form-radio text-primary-500">
                                <span class="ml-2 text-gray-700 dark:text-gray-300">Male</span>
                            </label>
                            <label class="inline-flex items-center">
                                <input type="radio" name="gender" value="female"
                                    class="form-radio text-primary-500">
                                <span class="ml-2 text-gray-700 dark:text-gray-300">Female</span>
                            </label>
                        </div>
                    </div>
                    
                    <div>
                        <label class="block text-gray-700 dark:text-gray-300 text-sm font-bold mb-2" for="image">
                            Profile Picture
                        </label>
                        <input type="file" id="image" name="image" accept="image/*"
                            class="form-input w-full px-4 py-2 border rounded-md focus:outline-none focus:ring-2 focus:ring-primary-500 dark:bg-gray-800 dark:border-gray-600 dark:text-white">
                    </div>
                    <div>
                        <label class="block text-gray-700 dark:text-gray-300 text-sm font-bold mb-2" for="id_card_image">
                            ID Card Image
                        </label>
                        <input type="file" id="id_card_image" name="id_card_image" accept="image/*"
                            class="form-input w-full px-4 py-2 border rounded-md focus:outline-none focus:ring-2 focus:ring-primary-500 dark:bg-gray-800 dark:border-gray-600 dark:text-white">
                    </div>
                </div>
                
                <!-- Hidden reCAPTCHA response field -->
                <input type="hidden" name="recaptcha_response" id="recaptchaResponse">
                
                <div class="mt-8">
                    <button type="submit"
                        class="w-full bg-primary-500 hover:bg-primary-600 text-white font-bold py-3 px-4 rounded-md transition duration-300 ease-in-out transform hover:scale-105">
                        Submit Application
                    </button>
                </div>
            </form>
            
            <div class="mt-8 text-center text-gray-600 dark:text-gray-400">
                <p>Already a member? Contact the club administration for any queries.</p>
            </div>
            
            <script>
            // Handle form submission with reCAPTCHA v3
            document.getElementById('joinForm').addEventListener('submit', function(e) {
                e.preventDefault();
                grecaptcha.ready(function() {
                    grecaptcha.execute('<?php echo $recaptcha_site_key; ?>', {action: 'join_submit'})
                    .then(function(token) {
                        document.getElementById('recaptchaResponse').value = token;
                        e.target.submit();
                    });
                });
            });
            </script>
        </div>
    </div>
</section>
<?php endif; ?>