<section class="bg-white dark:bg-gray-800 py-16 transition-colors duration-200">
    <div class="container mx-auto px-4 sm:px-6 lg:px-8">
        <div class="max-w-4xl mx-auto">
            <h1 class="text-3xl font-bold text-center text-gray-900 dark:text-white mb-10">About BGC Science Club</h1>
            
            <div class="mb-12 text-center">
                <img src="https://images.pexels.com/photos/3861969/pexels-photo-3861969.jpeg" alt="BGC Science Club" class="rounded-lg shadow-xl mx-auto mb-8">
            </div>
            
            <div class="prose prose-lg max-w-none dark:prose-invert">
                <p class="mb-6 text-gray-700 dark:text-gray-300">
                    The Brahmanbaria Government College Science Club was established in 2010 with the aim of promoting scientific knowledge, innovation, and research among the students of Brahmanbaria Government College. Since its inception, the club has been actively organizing various scientific events, workshops, seminars, and research activities.
                </p>
                
                <h2 class="text-2xl font-semibold text-gray-900 dark:text-white mt-10 mb-4">Our Vision</h2>
                <p class="mb-6 text-gray-700 dark:text-gray-300">
                    To create a scientific community that fosters curiosity, critical thinking, and innovation among students, and to contribute to the advancement of science and technology in Bangladesh.
                </p>
                
                <h2 class="text-2xl font-semibold text-gray-900 dark:text-white mt-10 mb-4">Our Mission</h2>
                <p class="mb-6 text-gray-700 dark:text-gray-300">
                    Our mission is to:
                </p>
                <ul class="list-disc pl-6 mb-6 text-gray-700 dark:text-gray-300">
                    <li class="mb-2">Promote scientific literacy and awareness among students</li>
                    <li class="mb-2">Provide opportunities for students to engage in hands-on scientific activities</li>
                    <li class="mb-2">Organize workshops, seminars, and competitions to enhance students' knowledge and skills</li>
                    <li class="mb-2">Encourage and support student research projects</li>
                    <li class="mb-2">Create a platform for students to interact with scientists and researchers</li>
                    <li class="mb-2">Foster collaboration and teamwork among students</li>
                </ul>
                
                <h2 class="text-2xl font-semibold text-gray-900 dark:text-white mt-10 mb-4">Our Activities</h2>
                <p class="mb-6 text-gray-700 dark:text-gray-300">
                    The BGC Science Club organizes a wide range of activities throughout the academic year, including:
                </p>
                <ul class="list-disc pl-6 mb-6 text-gray-700 dark:text-gray-300">
                    <li class="mb-2">Annual Science Fair</li>
                    <li class="mb-2">Science Quiz Competitions</li>
                    <li class="mb-2">Workshops on various scientific topics</li>
                    <li class="mb-2">Science Olympiads</li>
                    <li class="mb-2">Field trips to scientific institutions and research centers</li>
                    <li class="mb-2">Guest lectures by renowned scientists and researchers</li>
                    <li class="mb-2">Publication of science journals and newsletters</li>
                    <li class="mb-2">Science exhibitions and demonstrations</li>
                </ul>
                
                <h2 class="text-2xl font-semibold text-gray-900 dark:text-white mt-10 mb-4">Achievements</h2>
                <p class="mb-6 text-gray-700 dark:text-gray-300">
                    Over the years, the BGC Science Club has achieved numerous milestones, including:
                </p>
                <ul class="list-disc pl-6 mb-6 text-gray-700 dark:text-gray-300">
                    <li class="mb-2">Winning the District Level Science Project Competition in 2018 and 2019</li>
                    <li class="mb-2">Organizing the largest science fair in the district with over 100 projects</li>
                    <li class="mb-2">Publishing the bi-annual science journal "Science Horizon"</li>
                    <li class="mb-2">Collaborating with various scientific organizations for research projects</li>
                    <li class="mb-2">Sending students to national level science competitions</li>
                </ul>
                
                <h2 class="text-2xl font-semibold text-gray-900 dark:text-white mt-10 mb-4">Join Us</h2>
                <p class="mb-6 text-gray-700 dark:text-gray-300">
                    We welcome all students of Brahmanbaria Government College who are passionate about science to join our club. Membership in the BGC Science Club offers numerous benefits, including access to scientific resources, participation in exclusive events, and opportunities to develop leadership skills.
                </p>
                <p class="mb-6 text-gray-700 dark:text-gray-300">
                    To become a member, please fill out the <a href="/join" class="text-primary-500 hover:text-primary-600">membership application form</a>.
                </p>
                
                <div class="bg-gray-100 dark:bg-gray-700 p-6 rounded-lg mt-10">
                    <h3 class="text-xl font-semibold text-gray-900 dark:text-white mb-4">Contact Information</h3>
                    <p class="text-gray-700 dark:text-gray-300 mb-2">
                        <strong>Email:</strong> scienceclub@bgc.edu.bd
                    </p>
                    <p class="text-gray-700 dark:text-gray-300 mb-2">
                        <strong>Phone:</strong> +880 1234-567890
                    </p>
                    <p class="text-gray-700 dark:text-gray-300 mb-2">
                        <strong>Location:</strong> Room 301, Science Building, Brahmanbaria Government College, Brahmanbaria, Bangladesh
                    </p>
                    <p class="text-gray-700 dark:text-gray-300 mb-2">
                        <strong>Club Hours:</strong> Sunday to Thursday, 2:00 PM to 5:00 PM
                    </p>
                </div>
            </div>
        </div>
    </div>
</section>