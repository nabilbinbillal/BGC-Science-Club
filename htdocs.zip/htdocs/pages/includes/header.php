<!-- Google Translate Widget -->
<div class="gtranslate_wrapper"></div>
<script>
window.gtranslateSettings = {
    "default_language": "en",
    "native_language_names": true,
    "languages": ["en", "bn"],
    "wrapper_selector": ".gtranslate_wrapper",
    "switcher_horizontal_position": "right",
    "detect_browser_language": true,
    "flag_style": "3d",
    "float_switcher_open_direction": "top",
    "custom_domains": {
        "bn": "bn-BD"
    },
    "custom_css": `
        #goog-gt-tt, .goog-te-balloon-frame { font-family: 'Kalpurush', sans-serif !important; }
        .goog-text-highlight { font-family: 'Kalpurush', sans-serif !important; }
        .translated-content { font-family: 'Kalpurush', sans-serif !important; }
    `
}
</script>
<script src="https://cdn.gtranslate.net/widgets/latest/float.js" defer></script>

<header class="bg-white dark:bg-gray-800 shadow-md transition-colors duration-200">
    <div class="container mx-auto px-4 sm:px-6 lg:px-8">
        <div class="flex justify-between items-center py-4">
            <div class="flex items-center">
                <a href="/" class="flex items-center">
                    <img src="/assets/images/logo.png" alt="BGC Science Club Logo" class="h-12 w-12 rounded-full object-cover">
                    <span class="ml-3 text-xl font-semibold text-gray-900 dark:text-white no-translate">BGC Science Club</span>
                </a>
            </div>
            
            <nav class="hidden md:flex items-center space-x-4">
                <a href="/" class="<?php echo !isset($page) || $page === 'home' ? 'text-primary-500' : 'text-gray-700 dark:text-gray-300'; ?> px-3 py-2 rounded-md text-sm font-medium hover:text-primary-500">Home</a>
                <a href="/about" class="<?php echo $page === 'about' ? 'text-primary-500' : 'text-gray-700 dark:text-gray-300'; ?> px-3 py-2 rounded-md text-sm font-medium hover:text-primary-500">About</a>
                <a href="/executives" class="<?php echo $page === 'executives' ? 'text-primary-500' : 'text-gray-700 dark:text-gray-300'; ?> px-3 py-2 rounded-md text-sm font-medium hover:text-primary-500">Executives</a>
                <a href="/members" class="<?php echo $page === 'members' ? 'text-primary-500' : 'text-gray-700 dark:text-gray-300'; ?> px-3 py-2 rounded-md text-sm font-medium hover:text-primary-500">Members</a>
                <a href="/activities" class="<?php echo $page === 'activities' ? 'text-primary-500' : 'text-gray-700 dark:text-gray-300'; ?> px-3 py-2 rounded-md text-sm font-medium hover:text-primary-500">Activities</a>
                
                
                
                <a href="/join" class="px-4 py-2 rounded-md text-sm font-medium bg-secondary-500 hover:bg-secondary-600 text-white text-center">
                    Join Us
                </a>
                
                <!-- Admin panel button removed -->
            </nav>
            
            <!-- Mobile menu button -->
            <div class="md:hidden flex items-center">
                <button id="mobileMenuButton" class="text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-700 p-2 rounded-md focus:outline-none">
                    <svg class="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 6h16M4 12h16M4 18h16" />
                    </svg>
                </button>
            </div>
        </div>
        
        <!-- Mobile menu -->
        <div id="mobileMenu" class="hidden md:hidden">
            <div class="px-2 pt-2 pb-3 space-y-1">
                <a href="/" class="<?php echo !isset($page) || $page === 'home' ? 'bg-primary-500 text-white' : 'text-gray-700 dark:text-gray-300'; ?> block px-3 py-2 rounded-md text-base font-medium hover:bg-primary-500 hover:text-white">Home</a>
                <a href="/about" class="<?php echo $page === 'about' ? 'bg-primary-500 text-white' : 'text-gray-700 dark:text-gray-300'; ?> block px-3 py-2 rounded-md text-base font-medium hover:bg-primary-500 hover:text-white">About</a>
                <a href="/executives" class="<?php echo $page === 'executives' ? 'bg-primary-500 text-white' : 'text-gray-700 dark:text-gray-300'; ?> block px-3 py-2 rounded-md text-base font-medium hover:bg-primary-500 hover:text-white">Executives</a>
                <a href="/members" class="<?php echo $page === 'members' ? 'bg-primary-500 text-white' : 'text-gray-700 dark:text-gray-300'; ?> block px-3 py-2 rounded-md text-base font-medium hover:bg-primary-500 hover:text-white">Members</a>
                <a href="/activities" class="<?php echo $page === 'activities' ? 'bg-primary-500 text-white' : 'text-gray-700 dark:text-gray-300'; ?> block px-3 py-2 rounded-md text-base font-medium hover:bg-primary-500 hover:text-white">Activities</a>
                <a href="/join" class="block px-3 py-2 rounded-md text-base font-medium bg-secondary-500 hover:bg-secondary-600 text-white text-center">Join Us</a>
                
                <!-- Admin panel button removed from mobile menu -->
                
               
            </div>
        </div>
    </div>
</header>