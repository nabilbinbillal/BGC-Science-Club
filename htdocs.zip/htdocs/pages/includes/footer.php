<footer class="bg-white dark:bg-gray-800 shadow-md mt-auto">
    <div class="container mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div class="grid grid-cols-1 md:grid-cols-4 gap-8">
            <div class="col-span-1">
                <h3 class="text-lg font-semibold text-gray-900 dark:text-white mb-4">About Us</h3>
                <p class="text-gray-600 dark:text-gray-300">BGC Science Club is dedicated to fostering scientific curiosity and innovation among students.</p>
            </div>
            
            <div class="col-span-1">
                <h3 class="text-lg font-semibold text-gray-900 dark:text-white mb-4">Quick Links</h3>
                <ul class="space-y-2">
                    <li><a href="/about" class="text-gray-600 dark:text-gray-300 hover:text-primary-500 dark:hover:text-primary-400">About</a></li>
                    <li><a href="/executives" class="text-gray-600 dark:text-gray-300 hover:text-primary-500 dark:hover:text-primary-400">Executives</a></li>
                    <li><a href="/members" class="text-gray-600 dark:text-gray-300 hover:text-primary-500 dark:hover:text-primary-400">Members</a></li>
                    <li><a href="/activities" class="text-gray-600 dark:text-gray-300 hover:text-primary-500 dark:hover:text-primary-400">Activities</a></li>
                    <li><a href="/join" class="text-gray-600 dark:text-gray-300 hover:text-primary-500 dark:hover:text-primary-400">Join Us</a></li>
                    <li><a href="/about-developer" class="text-gray-600 dark:text-gray-300 hover:text-primary-500 dark:hover:text-primary-400">About Developer</a></li>
                </ul>
            </div>
            
            <div class="col-span-1">
                <h3 class="text-lg font-semibold text-gray-900 dark:text-white mb-4">Contact</h3>
                <ul class="space-y-2">
                    <li class="flex items-center text-gray-600 dark:text-gray-300">
                        <i class="fas fa-envelope mr-2"></i>
                        info@bgcscienceclub.com
                    </li>
                    <li class="flex items-center text-gray-600 dark:text-gray-300">
                        <i class="fas fa-phone mr-2"></i>
                        +880 1234-567890
                    </li>
                </ul>
            </div>
            
            <div class="col-span-1">
                <h3 class="text-lg font-semibold text-gray-900 dark:text-white mb-4">Follow Us</h3>
                <div class="flex space-x-4">
                    <a href="https://www.facebook.com/profile.php?id=61574939775582" class="text-gray-600 dark:text-gray-300 hover:text-primary-500 dark:hover:text-primary-400">
                        <i class="fab fa-facebook-f text-xl"></i>
                    </a>
                    <a href="https://www.x.com/BGCSC" class="text-gray-600 dark:text-gray-300 hover:text-primary-500 dark:hover:text-primary-400">
                        <i class="fab fa-twitter text-xl"></i>
                    </a>
                    <a href="https://www.linkedin.com/in/bgc-science-club" class="text-gray-600 dark:text-gray-300 hover:text-primary-500 dark:hover:text-primary-400">
                        <i class="fab fa-lnkedin text-xl"></i>
                    </a>
                </div>
            </div>
        </div>
        
        <div class="border-t border-gray-200 dark:border-gray-700 mt-8 pt-8">
            <div class="text-center">
                <p class="text-gray-600 dark:text-gray-400">
                    © <?php echo date('Y'); ?> Brahmanbaria Govt. College. All rights reserved.
                </p>
                <span class="mt-2 inline-flex items-center text-gray-600 dark:text-gray-400">
                    Developed with <span class="text-red-500 mx-1">❤</span> by 
                    <a href="/about-developer" class="text-primary-500 hover:text-primary-600 dark:text-primary-400 dark:hover:text-primary-300 font-semibold transition-colors duration-200 ml-1">
                        Nabil Bin Billal
                    </a>
                </span>
            </div>
        </div>
    </div>

    <!-- Google Translate Widget -->
    <div class="gtranslate_wrapper"></div>
    <script>window.gtranslateSettings = {"default_language":"en","native_language_names":true,"languages":["en","bn"],"wrapper_selector":".gtranslate_wrapper","switcher_horizontal_position":"right"}</script>
    <script src="https://cdn.gtranslate.net/widgets/latest/float.js" defer></script>
</footer>