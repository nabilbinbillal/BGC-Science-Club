<?php
// Include DB connection
include '../config/db.php';  // Make sure this path is correct

// Get executive slug from URL (assuming slug is in URL)
$slug = isset($_GET['slug']) ? $_GET['slug'] : '';

// Fetch executive data based on slug using PDO
$query = "SELECT * FROM executives WHERE slug = :slug";
$stmt = $pdo->prepare($query);
$stmt->bindParam(':slug', $slug, PDO::PARAM_STR);
$stmt->execute();
$executive = $stmt->fetch();

// Fallback if no executive found
if (!$executive) {
    echo "Executive not found.";
    exit;
}

// Set page metadata
$pageTitle = "Executive - " . htmlspecialchars($executive['name']);
$pageDescription = "Details about " . htmlspecialchars($executive['name']) . ", one of our executive members.";
?>

<?php include '../includes/header.php'; ?>

<link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
<link rel="stylesheet" href="assets/css/style.css">

<div class="bg-white dark:bg-gray-800">
    <div class="container mx-auto px-4 py-16">
        <div class="max-w-4xl mx-auto">

            <!-- Profile Header -->
            <div class="text-center mb-12">
                <img src="<?= htmlspecialchars($executive['profile_pic']) ?>" 
                     alt="<?= htmlspecialchars($executive['name']) ?>" 
                     class="w-48 h-48 rounded-full mx-auto mb-6 shadow-lg">
                <h1 class="text-3xl font-bold text-gray-900 dark:text-white mb-2"><?= htmlspecialchars($executive['name']) ?></h1>
                <p class="text-lg text-gray-600 dark:text-gray-400"><?= htmlspecialchars($executive['position']) ?></p>
            </div>

            <!-- About Section -->
            <div class="prose dark:prose-invert max-w-none mb-12">
                <h2 class="text-2xl font-bold text-gray-900 dark:text-white mb-4">About</h2>
                <p class="text-gray-700 dark:text-gray-300">
                    <?= nl2br(html_entity_decode($executive['bio'])) ?>
                </p>
            </div>

            <!-- Social Links -->
            <?php
                $socials = json_decode($executive['social_links'], true); // Assuming links stored as JSON
                if (!empty($socials)) :
            ?>
            <div class="bg-gray-50 dark:bg-gray-700 rounded-lg p-6 mb-12">
                <h2 class="text-2xl font-bold text-gray-900 dark:text-white mb-6">Connect</h2>
                <div class="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
                    <?php foreach ($socials as $platform => $link): ?>
                        <a href="<?= htmlspecialchars($link) ?>" target="_blank" rel="nofollow" class="flex items-center p-3 bg-white dark:bg-gray-800 rounded-lg hover:shadow-md transition-shadow">
                            <i class="fab fa-<?= strtolower($platform) ?> mr-3 text-lg"></i>
                            <span class="text-gray-700 dark:text-gray-300"><?= ucfirst($platform) ?></span>
                        </a>
                    <?php endforeach; ?>
                </div>
            </div>
            <?php endif; ?>

        </div>
    </div>
</div>

<?php include '../includes/footer.php'; ?>
