<?php
// Get departments from function
$departments = getDepartmentOptions();
$departmentOptions = array_combine($departments, $departments); // Create key-value pairs

// Get archive year filter
$selectedYear = isset($_GET['year']) ? $_GET['year'] : 'all';

// Handle member actions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['action'])) {
        $memberId = isset($_POST['member_id']) ? $_POST['member_id'] : null;
        
        switch ($_POST['action']) {
            case 'approve':
                try {
                    $stmt = $pdo->prepare("UPDATE members SET status = 'approved' WHERE id = ?");
                    $stmt->execute([$memberId]);
                    $success = "Member approved successfully";
                } catch (PDOException $e) {
                    $error = "An error occurred while approving the member";
                }
                break;
                
            case 'promote':
                try {
                    $position = isset($_POST['position']) ? $_POST['position'] : 'Executive Member';
                    $executive_type = $_POST['executive_type'];
                    $about = $_POST['about'];
                    $stmt = $pdo->prepare("UPDATE members SET role = 'executive', position = ?, executive_type = ?, about = ? WHERE id = ?");
                    $stmt->execute([$position, $executive_type, $about, $memberId]);
                    $success = "Member promoted to executive successfully";
                } catch (PDOException $e) {
                    $error = "An error occurred while promoting the member";
                }
                break;
                
            case 'delete':
                try {
                    $stmt = $pdo->prepare("DELETE FROM members WHERE id = ?");
                    $stmt->execute([$memberId]);
                    $success = "Member deleted successfully";
                } catch (PDOException $e) {
                    $error = "An error occurred while deleting the member";
                }
                break;
        }
    } else {
        // Add/Edit member
        $name = sanitize($_POST['name']);
        $department = sanitize($_POST['department']);
        $roll_no = sanitize($_POST['roll_no']);
        $email = sanitize($_POST['email']);
        $phone = sanitize($_POST['phone']);
        $gender = sanitize($_POST['gender']);
        $memberId = isset($_POST['member_id']) ? $_POST['member_id'] : null;
        
        // Generate unique member ID if new member
        if (!$memberId) {
            $uniqueId = generateMemberId();
        }
        
        // Handle profile picture upload with compression
        $profile_pic = null;
        if (isset($_FILES['profile_pic']) && $_FILES['profile_pic']['error'] === 0) {
            $uploadDir = '../uploads/members/';
            $profile_pic = uploadMemberImage($_FILES['profile_pic'], $uploadDir);
        }
        
        try {
            if ($memberId) {
                // Update existing member
                $sql = "UPDATE members SET name = ?, department = ?, roll_no = ?, email = ?, phone = ?, gender = ?";
                $params = [$name, $department, $roll_no, $email, $phone, $gender];
                
                if ($profile_pic) {
                    $sql .= ", profile_pic = ?";
                    $params[] = $profile_pic;
                }
                
                $sql .= " WHERE id = ?";
                $params[] = $memberId;
                
                $stmt = $pdo->prepare($sql);
                $stmt->execute($params);
                
                $success = "Member updated successfully";
            } else {
                // Create new member
                $stmt = $pdo->prepare("INSERT INTO members (member_id, name, department, roll_no, email, phone, gender, profile_pic, status) VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'pending')");
                $stmt->execute([$uniqueId, $name, $department, $roll_no, $email, $phone, $gender, $profile_pic]);
                
                $success = "Member added successfully";
            }
        } catch (PDOException $e) {
            $error = "An error occurred. Please try again.";
        }
    }
}

// Get pending requests
$stmt = $pdo->query("SELECT * FROM members WHERE status = 'pending' ORDER BY created_at DESC");
$pendingMembers = $stmt->fetchAll();

// Get approved members with archive year filter
$sql = "SELECT * FROM members WHERE status = 'approved' AND role = 'member'";
$params = [];

if ($selectedYear !== 'all') {
    if ($selectedYear === 'current') {
        $sql .= " AND (archive_year IS NULL OR archive_year = '')";
    } else {
        $sql .= " AND archive_year = ?";
        $params[] = $selectedYear;
    }
}

$sql .= " ORDER BY name ASC";

$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$approvedMembers = $stmt->fetchAll();
?>


<!-- Add Member Button -->
<div class="flex justify-between items-center mb-6">
    <h2 class="text-2xl font-semibold text-gray-900 dark:text-white">Members Management</h2>
    <div class="space-x-2">
        <button id="showAddMemberForm" class="bg-primary-500 hover:bg-primary-600 text-white font-bold py-2 px-4 rounded inline-flex items-center">
            <i class="fas fa-plus mr-2"></i> Add Member
        </button>
    </div>
</div>

<!-- Archive Year Filter -->
<div class="mb-6 max-w-xs">
    <form method="GET" action="/admin/pages/members.php" class="flex space-x-2">
        <select name="year" class="w-full px-4 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-primary-500 focus:border-primary-500 dark:bg-gray-700 dark:border-gray-600 dark:text-white">
            <option value="all" <?php echo $selectedYear == 'all' ? 'selected' : ''; ?>>All Members</option>
            <option value="current" <?php echo $selectedYear == 'current' ? 'selected' : ''; ?>>Current Members</option>
            <?php
            $yearStmt = $pdo->query("SELECT DISTINCT archive_year FROM members WHERE archive_year IS NOT NULL ORDER BY archive_year DESC");
            $archiveYears = $yearStmt->fetchAll(PDO::FETCH_COLUMN);
            foreach ($archiveYears as $year) {
                echo '<option value="' . htmlspecialchars($year) . '"' . ($selectedYear == $year ? ' selected' : '') . '>Members - ' . htmlspecialchars($year) . '</option>';
            }
            ?>
        </select>
        <button type="submit" class="px-4 py-2 bg-primary-500 text-white rounded hover:bg-primary-600">Filter</button>
    </form>
</div>

<!-- Member Form (Show if adding or editing) -->
<div id="memberFormContainer" class="mb-8<?php echo isset($_GET['edit']) ? '' : ' hidden'; ?>">
    <div class="bg-white dark:bg-gray-800 rounded-lg shadow-md overflow-hidden">
        <div class="p-6">
            <h2 class="text-xl font-semibold text-gray-900 dark:text-white mb-6">
                <?php echo isset($_GET['edit']) ? 'Edit Member' : 'Add New Member'; ?>
            </h2>
            
            <?php if (isset($success)): ?>
            <div class="bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded mb-4">
                <?php echo $success; ?>
            </div>
            <?php endif; ?>
            
            <?php if (isset($error)): ?>
            <div class="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded mb-4">
                <?php echo $error; ?>
            </div>
            <?php endif; ?>
            
            <form method="POST" enctype="multipart/form-data" class="space-y-6">
                <?php
                if (isset($_GET['edit'])) {
                    $editId = $_GET['edit'];
                    $stmt = $pdo->prepare("SELECT * FROM members WHERE id = ?");
                    $stmt->execute([$editId]);
                    $member = $stmt->fetch();
                }
                ?>
                
                <?php if (isset($member)): ?>
                <input type="hidden" name="member_id" value="<?php echo $member['id']; ?>">
                <?php endif; ?>
                
                <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div>
                        <label class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2" for="name">
                            Name
                        </label>
                        <input type="text" id="name" name="name" required
                            value="<?php echo isset($member) ? htmlspecialchars($member['name']) : ''; ?>"
                            class="w-full px-4 py-2 rounded-md border-gray-300 dark:border-gray-600 focus:border-primary-500 focus:ring focus:ring-primary-500 focus:ring-opacity-50 dark:bg-gray-700 dark:text-white transition duration-150 ease-in-out">
                    </div>
                    
                    <div>
                        <label class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2" for="department">
                            Department/Class
                        </label>
                        <select id="department" name="department" required 
                            class="w-full px-4 py-2 rounded-md border-gray-300 dark:border-gray-600 focus:border-primary-500 focus:ring focus:ring-primary-500 focus:ring-opacity-50 dark:bg-gray-700 dark:text-white transition duration-150 ease-in-out">
                            <option value="">Select Department/Class</option>
                            <?php foreach ($departmentOptions as $key => $value): ?>
                            <option value="<?php echo $key; ?>" <?php echo (isset($member) && $member['department'] === $key) ? 'selected' : ''; ?>>
                                <?php echo $value; ?>
                            </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    
                    <div>
                        <label class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2" for="roll_no">
                            Roll Number
                        </label>
                        <input type="text" id="roll_no" name="roll_no" required
                            value="<?php echo isset($member) ? htmlspecialchars($member['roll_no']) : ''; ?>"
                            class="w-full px-4 py-2 rounded-md border-gray-300 dark:border-gray-600 focus:border-primary-500 focus:ring focus:ring-primary-500 focus:ring-opacity-50 dark:bg-gray-700 dark:text-white transition duration-150 ease-in-out">
                    </div>
                    
                    <div>
                        <label class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2" for="email">
                            Email
                        </label>
                        <input type="email" id="email" name="email" required
                            value="<?php echo isset($member) ? htmlspecialchars($member['email']) : ''; ?>"
                            class="w-full px-4 py-2 rounded-md border-gray-300 dark:border-gray-600 focus:border-primary-500 focus:ring focus:ring-primary-500 focus:ring-opacity-50 dark:bg-gray-700 dark:text-white transition duration-150 ease-in-out">
                    </div>
                    
                    <div>
                        <label class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2" for="phone">
                            Phone
                        </label>
                        <input type="tel" id="phone" name="phone" required
                            value="<?php echo isset($member) ? htmlspecialchars($member['phone']) : ''; ?>"
                            class="w-full px-4 py-2 rounded-md border-gray-300 dark:border-gray-600 focus:border-primary-500 focus:ring focus:ring-primary-500 focus:ring-opacity-50 dark:bg-gray-700 dark:text-white transition duration-150 ease-in-out">
                    </div>
                    
                    <div>
                        <label class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2" for="gender">
                            Gender
                        </label>
                        <select id="gender" name="gender" required 
                            class="w-full px-4 py-2 rounded-md border-gray-300 dark:border-gray-600 focus:border-primary-500 focus:ring focus:ring-primary-500 focus:ring-opacity-50 dark:bg-gray-700 dark:text-white transition duration-150 ease-in-out">
                            <option value="">Select Gender</option>
                            <option value="male" <?php echo (isset($member) && $member['gender'] === 'male') ? 'selected' : ''; ?>>Male</option>
                            <option value="female" <?php echo (isset($member) && $member['gender'] === 'female') ? 'selected' : ''; ?>>Female</option>
                        </select>
                    </div>
                    
                    <div>
                        <label class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2" for="profile_pic">
                        <input type="text" id="name" name="name" required
                            Profile Picture
                        </label>
                        <input type="file" id="profile_pic" name="profile_pic" accept="image/*"
                            class="w-full px-4 py-2 rounded-md border-gray-300 dark:border-gray-600 focus:border-primary-500 focus:ring focus:ring-primary-500 focus:ring-opacity-50 dark:bg-gray-700 dark:text-white transition duration-150 ease-in-out">
                    </div>
                </div>
                
                <div class="flex justify-end space-x-2">
                    <a href="?page=members" id="cancelAddMember"
                        class="bg-gray-500 hover:bg-gray-600 text-white font-bold py-2 px-4 rounded transition duration-150 ease-in-out">
                        Cancel
                    </a>
                    <button type="submit"
                        class="bg-primary-500 hover:bg-primary-600 text-white font-bold py-2 px-4 rounded transition duration-150 ease-in-out">
                        <?php echo isset($member) ? 'Update Member' : 'Add Member'; ?>
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>
                        </label>

<div class="grid grid-cols-1 gap-8">
    <!-- Pending Requests -->
    <div class="bg-white dark:bg-gray-800 rounded-lg shadow-md overflow-hidden">
        <div class="p-6">
            <h2 class="text-xl font-semibold text-gray-900 dark:text-white mb-6">Pending Requests</h2>
            
            <div class="overflow-x-auto">
                <table class="min-w-full">
                    <thead>
                        <tr class="bg-gray-50 dark:bg-gray-700">
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">Name</th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">Department</th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">Roll No</th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">Actions</th>
                        </tr>
                    </thead>
                    <tbody class="bg-white dark:bg-gray-800 divide-y divide-gray-200 dark:divide-gray-700">
                        <?php foreach ($pendingMembers as $member): ?>
                        <tr>
                            <td class="px-6 py-4 whitespace-nowrap">
                                <div class="flex items-center">
<?php if (isset($member['profile_pic']) && $member['profile_pic']): ?>
<img src="../uploads/members/<?php echo $member['profile_pic']; ?>" 
    alt="<?php echo htmlspecialchars($member['name']); ?>"
    class="h-10 w-10 rounded-full">
<?php else: ?>
<img src="https://ui-avatars.com/api/?name=<?php echo urlencode($member['name']); ?>&background=random" 
    alt="<?php echo htmlspecialchars($member['name']); ?>"
    class="h-10 w-10 rounded-full">
<?php endif; ?>
                                    <div class="ml-4">
                                        <div class="text-sm font-medium text-gray-900 dark:text-white">
                                            <?php echo htmlspecialchars($member['name']); ?>
                                        </div>
                                        <div class="text-sm text-gray-500 dark:text-gray-400">
                                            <?php echo htmlspecialchars($member['email']); ?>
                                        </div>
                                    </div>
                                </div>
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500 dark:text-gray-400">
                                <?php echo htmlspecialchars($member['department']); ?>
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500 dark:text-gray-400">
                                <?php echo htmlspecialchars($member['roll_no']); ?>
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                                <form method="POST" class="inline-block">
                                    <input type="hidden" name="member_id" value="<?php echo $member['id']; ?>">
                                    <input type="hidden" name="action" value="approve">
                                    <button type="submit" class="text-primary-500 hover:text-primary-600">Approve</button>
                                </form>
                                <span class="px-2 text-gray-400">|</span>
                                <form method="POST" class="inline-block">
                                    <input type="hidden" name="member_id" value="<?php echo $member['id']; ?>">
                                    <input type="hidden" name="action" value="delete">
                                    <button type="submit" class="text-red-500 hover:text-red-600"
                                        onclick="return confirm('Are you sure you want to delete this request?')">
                                        Delete
                                    </button>
                                </form>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    
    <!-- Approved Members -->
    <div class="bg-white dark:bg-gray-800 rounded-lg shadow-md overflow-hidden">
        <div class="p-6">
            <h2 class="text-xl font-semibold text-gray-900 dark:text-white mb-6">Approved Members</h2>
            
            <div class="overflow-x-auto">
                <table class="min-w-full">
                    <thead>
                        <tr class="bg-gray-50 dark:bg-gray-700">
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">Name</th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">Department</th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">Member ID</th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">Role</th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">Actions</th>
                        </tr>
                    </thead>
                    <tbody class="bg-white dark:bg-gray-800 divide-y divide-gray-200 dark:divide-gray-700">
                        <?php foreach ($approvedMembers as $member): ?>
                        <tr>
                            <td class="px-6 py-4 whitespace-nowrap">
                                <div class="flex items-center">
<?php if (isset($member['profile_pic']) && $member['profile_pic']): ?>
<img src="../uploads/members/<?php echo $member['profile_pic']; ?>" 
    alt="<?php echo htmlspecialchars($member['name']); ?>"
    class="h-10 w-10 rounded-full">
<?php else: ?>
<img src="https://ui-avatars.com/api/?name=<?php echo urlencode($member['name']); ?>&background=random" 
    alt="<?php echo htmlspecialchars($member['name']); ?>"
    class="h-10 w-10 rounded-full">
<?php endif; ?>
                                    <div class="ml-4">
                                        <div class="text-sm font-medium text-gray-900 dark:text-white">
                                            <?php echo htmlspecialchars($member['name']); ?>
                                        </div>
                                        <div class="text-sm text-gray-500 dark:text-gray-400">
                                            <?php echo htmlspecialchars($member['email']); ?>
                                        </div>
                                    </div>
                                </div>
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500 dark:text-gray-400">
                                <?php echo htmlspecialchars($member['department']); ?>
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500 dark:text-gray-400">
                                <?php echo htmlspecialchars($member['member_id']); ?>
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500 dark:text-gray-400">
                                <?php echo ucfirst($member['role'] ?? 'member'); ?>
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap text-right text-sm font-medium space-x-2">
                                <a href="?page=members&edit=<?php echo $member['id']; ?>" class="text-primary-500 hover:text-primary-600 mr-3">Edit</a>
                                <?php if (($member['role'] ?? 'member') !== 'executive'): ?>
                                <button type="button" onclick="showPromoteModal(<?php echo $member['id']; ?>, '<?php echo htmlspecialchars($member['name']); ?>')" 
                                    class="text-green-500 hover:text-green-600">
                                    Promote to Executive
                                </button>
                                <?php endif; ?>
                                
                                <form method="POST" class="inline-block">
                                    <input type="hidden" name="member_id" value="<?php echo $member['id']; ?>">
                                    <input type="hidden" name="action" value="delete">
                                    <button type="submit" class="text-red-500 hover:text-red-600"
                                        onclick="return confirm('Are you sure you want to delete this member?')">
                                        Delete
                                    </button>
                                </form>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<!-- Promote Modal -->
<div id="promoteModal" class="fixed inset-0 z-50 hidden overflow-y-auto" aria-labelledby="modal-title" role="dialog" aria-modal="true">
    <div class="flex items-end justify-center min-h-screen pt-4 px-4 pb-20 text-center sm:block sm:p-0">
        <div class="fixed inset-0 bg-gray-500 bg-opacity-75 transition-opacity" aria-hidden="true"></div>
        
        <div class="inline-block align-bottom bg-white dark:bg-gray-800 rounded-lg text-left overflow-hidden shadow-xl transform transition-all sm:my-8 sm:align-middle sm:max-w-lg sm:w-full">
            <form id="promoteForm" method="POST" class="relative">
                <div class="bg-white dark:bg-gray-800 px-4 pt-5 pb-4 sm:p-6 sm:pb-4">
                    <div class="sm:flex sm:items-start">
                        <div class="mx-auto flex-shrink-0 flex items-center justify-center h-12 w-12 rounded-full bg-green-100 sm:mx-0 sm:h-10 sm:w-10">
                            <svg class="h-6 w-6 text-green-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
                            </svg>
                        </div>
                        <div class="mt-3 text-center sm:mt-0 sm:ml-4 sm:text-left w-full">
                            <h3 class="text-lg leading-6 font-medium text-gray-900 dark:text-white" id="modal-title"></h3>
                            <div class="mt-4 space-y-4">
                                <input type="hidden" name="member_id" id="promoteMemberId">
                                <input type="hidden" name="action" value="promote">
                                
                                <div>
                                    <label class="block text-sm font-medium text-gray-700 dark:text-gray-300">Executive Type</label>
                                    <select name="executive_type" class="mt-1 block w-full rounded-md border-gray-300 dark:border-gray-600 dark:bg-gray-700 shadow-sm focus:border-green-500 focus:ring-green-500" required>
                                        <option value="">Select Type</option>
                                        <option value="teacher">Teacher</option>
                                        <option value="student">Student</option>
                                    </select>
                                </div>
                                
                                <div>
                                    <label class="block text-sm font-medium text-gray-700 dark:text-gray-300">Position</label>
                                    <select name="position" class="mt-1 block w-full rounded-md border-gray-300 dark:border-gray-600 dark:bg-gray-700 shadow-sm focus:border-green-500 focus:ring-green-500" required>
                                        <option value="">Select Position</option>
                                        <?php foreach (getPositionOptions() as $pos): ?>
                                        <option value="<?php echo $pos; ?>"><?php echo $pos; ?></option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>
                                
                                <div>
                                    <label class="block text-sm font-medium text-gray-700 dark:text-gray-300">About</label>
                                    <textarea name="about" rows="3" class="mt-1 block w-full rounded-md border-gray-300 dark:border-gray-600 dark:bg-gray-700 shadow-sm focus:border-green-500 focus:ring-green-500" 
                                        placeholder="Brief introduction and responsibilities..." required></textarea>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="bg-gray-50 dark:bg-gray-700 px-4 py-3 sm:px-6 sm:flex sm:flex-row-reverse">
                    <button type="submit" class="w-full inline-flex justify-center rounded-md border border-transparent shadow-sm px-4 py-2 bg-green-600 text-base font-medium text-white hover:bg-green-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-green-500 sm:ml-3 sm:w-auto sm:text-sm">
                        Promote
                    </button>
                    <button type="button" onclick="hidePromoteModal()" class="mt-3 w-full inline-flex justify-center rounded-md border border-gray-300 shadow-sm px-4 py-2 bg-white dark:bg-gray-800 text-base font-medium text-gray-700 dark:text-gray-300 hover:bg-gray-50 dark:hover:bg-gray-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-gray-500 sm:mt-0 sm:ml-3 sm:w-auto sm:text-sm">
                        Cancel
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
function showPromoteModal(memberId, memberName) {
    document.getElementById('promoteMemberId').value = memberId;
    document.getElementById('modal-title').textContent = `Promote ${memberName} to Executive`;
    document.getElementById('promoteModal').classList.remove('hidden');
}

function hidePromoteModal() {
    document.getElementById('promoteModal').classList.add('hidden');
    document.getElementById('promoteForm').reset();
}

// Add confirmation before submitting promotion
document.getElementById('promoteForm').addEventListener('submit', function(e) {
    e.preventDefault();
    if (confirm('Are you sure you want to promote this member to executive? This action cannot be undone.')) {
        this.submit();
    }
});

// Close modal when clicking outside
document.getElementById('promoteModal').addEventListener('click', function(e) {
    if (e.target === this) {
        hidePromoteModal();
    }
});

// Cancel button functionality
document.querySelectorAll('[onclick="hidePromoteModal()"]').forEach(button => {
    button.addEventListener('click', function(e) {
        e.preventDefault();
        hidePromoteModal();
    });
});
</script>