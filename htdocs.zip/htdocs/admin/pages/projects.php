<?php

require_once __DIR__ . '/../../config/db.php';
require_once '../includes/functions.php';

// Handle add/edit/delete project
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $title = sanitize($_POST['title']);
    $description = sanitize($_POST['description']);
    $date = $_POST['date'];
    $link = sanitize($_POST['link']);
    $project_id = isset($_POST['project_id']) ? $_POST['project_id'] : null;

    // Handle image upload
    $image = null;
    if (isset($_FILES['image']) && $_FILES['image']['error'] === 0) {
        $uploadDir = '../uploads/projects/';
        if (!file_exists($uploadDir)) {
            mkdir($uploadDir, 0777, true);
        }
        $fileExt = strtolower(pathinfo($_FILES['image']['name'], PATHINFO_EXTENSION));
        $fileName = uniqid() . '.' . $fileExt;
        $targetFile = $uploadDir . $fileName;
        if (move_uploaded_file($_FILES['image']['tmp_name'], $targetFile)) {
            $image = $fileName;
        }
    }

    try {
        if ($project_id) {
            // Update project
            $sql = "UPDATE projects SET title=?, description=?, date=?, link=?";
            $params = [$title, $description, $date, $link];
            if ($image) {
                $sql .= ", image=?";
                $params[] = $image;
            }
            $sql .= " WHERE id=?";
            $params[] = $project_id;
            $stmt = $pdo->prepare($sql);
            $stmt->execute($params);
            $success = "Project updated successfully.";
        } else {
            // Add project
            $stmt = $pdo->prepare("INSERT INTO projects (title, description, date, link, image) VALUES (?, ?, ?, ?, ?)");
            $stmt->execute([$title, $description, $date, $link, $image]);
            $success = "Project added successfully.";
        }
    } catch (PDOException $e) {
        $error = "An error occurred. Please try again.";
    }
}

// Handle delete
if (isset($_GET['delete'])) {
    $deleteId = $_GET['delete'];
    try {
        $stmt = $pdo->prepare("DELETE FROM projects WHERE id = ?");
        $stmt->execute([$deleteId]);
        $success = "Project deleted successfully.";
    } catch (PDOException $e) {
        $error = "An error occurred. Please try again.";
    }
}

// Get projects
$stmt = $pdo->query("SELECT * FROM projects ORDER BY date DESC");
$projects = $stmt->fetchAll();

// If editing, get project data
if (isset($_GET['edit'])) {
    $editId = $_GET['edit'];
    $stmt = $pdo->prepare("SELECT * FROM projects WHERE id = ?");
    $stmt->execute([$editId]);
    $project = $stmt->fetch();
}
?>
<div class="bg-white dark:bg-gray-800 rounded-lg shadow-md p-6 mb-8">
    <h2 class="text-2xl font-semibold text-gray-900 dark:text-white mb-6"><?php echo isset($project) ? 'Edit Project' : 'Add New Project'; ?></h2>
    <?php if (isset($success)): ?>
        <div class="bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded mb-4"><?php echo $success; ?></div>
    <?php endif; ?>
    <?php if (isset($error)): ?>
        <div class="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded mb-4"><?php echo $error; ?></div>
    <?php endif; ?>
    <form method="POST" enctype="multipart/form-data">
        <?php if (isset($project)): ?>
            <input type="hidden" name="project_id" value="<?php echo $project['id']; ?>">
        <?php endif; ?>
        <div class="mb-4">
            <label class="block text-gray-700 dark:text-gray-300 text-sm font-bold mb-2">Project Title</label>
            <input type="text" name="title" required value="<?php echo isset($project) ? htmlspecialchars($project['title']) : ''; ?>" class="form-input w-full px-4 py-2 border rounded-md focus:outline-none focus:ring-2 focus:ring-primary-500 dark:bg-gray-700 dark:border-gray-600 dark:text-white">
        </div>
        <div class="mb-4">
            <label class="block text-gray-700 dark:text-gray-300 text-sm font-bold mb-2">Date</label>
            <input type="date" name="date" required value="<?php echo isset($project) ? $project['date'] : ''; ?>" class="form-input w-full px-4 py-2 border rounded-md focus:outline-none focus:ring-2 focus:ring-primary-500 dark:bg-gray-700 dark:border-gray-600 dark:text-white">
        </div>
        <div class="mb-4">
            <label class="block text-gray-700 dark:text-gray-300 text-sm font-bold mb-2">Description</label>
            <textarea name="description" rows="3" class="form-textarea w-full px-4 py-2 border rounded-md focus:outline-none focus:ring-2 focus:ring-primary-500 dark:bg-gray-700 dark:border-gray-600 dark:text-white"><?php echo isset($project) ? htmlspecialchars($project['description']) : ''; ?></textarea>
        </div>
        <div class="mb-4">
            <label class="block text-gray-700 dark:text-gray-300 text-sm font-bold mb-2">Project Link</label>
            <input type="url" name="link" value="<?php echo isset($project) ? htmlspecialchars($project['link']) : ''; ?>" class="form-input w-full px-4 py-2 border rounded-md focus:outline-none focus:ring-2 focus:ring-primary-500 dark:bg-gray-700 dark:border-gray-600 dark:text-white">
        </div>
        <div class="mb-4">
            <label class="block text-gray-700 dark:text-gray-300 text-sm font-bold mb-2">Image</label>
            <input type="file" name="image" accept="image/*" class="form-input w-full px-4 py-2 border rounded-md focus:outline-none focus:ring-2 focus:ring-primary-500 dark:bg-gray-700 dark:border-gray-600 dark:text-white">
            <?php if (isset($project) && $project['image']): ?>
                <img src="../uploads/projects/<?php echo $project['image']; ?>" alt="Project Image" class="h-16 mt-2 rounded">
            <?php endif; ?>
        </div>
        <div class="flex space-x-2">
            <button type="submit" class="bg-primary-500 hover:bg-primary-600 text-white font-bold py-2 px-4 rounded">
                <?php echo isset($project) ? 'Update Project' : 'Add Project'; ?>
            </button>
            <?php if (isset($project)): ?>
                <a href="index.php?page=projects" class="bg-gray-500 hover:bg-gray-600 text-white font-bold py-2 px-4 rounded">Cancel</a>
            <?php endif; ?>
        </div>
    </form>
</div>

<div class="bg-white dark:bg-gray-800 rounded-lg shadow-md p-6">
    <h2 class="text-xl font-semibold text-gray-900 dark:text-white mb-6">All Projects</h2>
    <div class="overflow-x-auto">
        <table class="min-w-full divide-y divide-gray-200 dark:divide-gray-700">
            <thead>
                <tr class="bg-gray-50 dark:bg-gray-700">
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">Title</th>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">Date</th>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">Link</th>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">Image</th>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">Actions</th>
                </tr>
            </thead>
            <tbody class="divide-y divide-gray-200 dark:divide-gray-700">
                <?php foreach ($projects as $prj): ?>
                    <tr>
                        <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900 dark:text-white"><?php echo htmlspecialchars($prj['title']); ?></td>
                        <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500 dark:text-gray-400"><?php echo htmlspecialchars($prj['date']); ?></td>
                        <td class="px-6 py-4 whitespace-nowrap text-sm">
                            <?php if ($prj['link']): ?>
                                <a href="<?php echo htmlspecialchars($prj['link']); ?>" target="_blank" class="text-primary-500 hover:underline">View</a>
                            <?php endif; ?>
                        </td>
                        <td class="px-6 py-4 whitespace-nowrap text-sm">
                            <?php if ($prj['image']): ?>
                                <img src="../uploads/projects/<?php echo $prj['image']; ?>" alt="Project Image" class="h-10 rounded">
                            <?php endif; ?>
                        </td>
                        <td class="px-6 py-4 whitespace-nowrap text-sm font-medium">
                            <a href="index.php?page=projects&edit=<?php echo $prj['id']; ?>" class="text-primary-500 hover:text-primary-600 mr-3">Edit</a>
                            <a href="index.php?page=projects&delete=<?php echo $prj['id']; ?>" class="text-red-500 hover:text-red-600" onclick="return confirm('Are you sure you want to delete this project?')">Delete</a>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>
