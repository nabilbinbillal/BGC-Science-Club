<?php
if (!defined('ADMIN')) {
    exit;
}

require_once __DIR__ . '/../../config/db.php';

// Check if sort_order column exists, if not create it
$checkColumn = $pdo->query("SHOW COLUMNS FROM executives LIKE 'sort_order'");
if ($checkColumn->rowCount() == 0) {
    $pdo->exec("ALTER TABLE executives ADD COLUMN sort_order INT DEFAULT 0");
    // Initialize sort_order for existing records
    $pdo->exec("UPDATE executives SET sort_order = id WHERE sort_order = 0");
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['action'])) {
        $action = $_POST['action'];

        if ($action == 'add' || $action == 'edit') {
            $name = sanitize($_POST['name']);
            $type = sanitize($_POST['type']);
            $department = sanitize($_POST['department']);
            $role = sanitize($_POST['role']);
            $bio = sanitize($_POST['bio']);
            $website = sanitize($_POST['website']);

            // Handle social links
            $socialLinks = [
                'facebook' => $_POST['facebook'] ?? '',
                'twitter' => $_POST['twitter'] ?? '',
                'linkedin' => $_POST['linkedin'] ?? '',
                'instagram' => $_POST['instagram'] ?? ''
            ];

            // Additional fields for students
            $rollNo = $type == 'student' ? sanitize($_POST['roll_no']) : '';
            $session = $type == 'student' ? sanitize($_POST['session']) : '';

            // Handle file upload
            $profilePic = '';
            if (!empty($_FILES['profile_pic']['name'])) {
                $target_dir = "../uploads/executives/";
                if (!file_exists($target_dir)) {
                    mkdir($target_dir, 0777, true);
                }

                $extension = strtolower(pathinfo($_FILES["profile_pic"]["name"], PATHINFO_EXTENSION));
                $profilePic = uniqid() . '.' . $extension;
                $target_file = $target_dir . $profilePic;

                if (move_uploaded_file($_FILES["profile_pic"]["tmp_name"], $target_file)) {
                    // File uploaded successfully
                } else {
                    $_SESSION['error'] = "Sorry, there was an error uploading your file.";
                }
            }

            if ($action == 'add') {
                $slug = generateExecutiveSlug($name);
                $stmt = $pdo->prepare("INSERT INTO executives (name, slug, type, department, role, bio, website, social_links, roll_no, session, profile_pic, sort_order, archive_year) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, (SELECT COALESCE(MAX(sort_order), 0) + 1 FROM executives e), NULL)");
                $stmt->execute([$name, $slug, $type, $department, $role, $bio, $website, json_encode($socialLinks), $rollNo, $session, $profilePic]);
                $_SESSION['success'] = "Executive added successfully!";
            } else {
                $id = $_POST['id'];
                $currentSlug = $_POST['current_slug'];
                $slug = ($name !== $_POST['original_name']) ? generateExecutiveSlug($name) : $currentSlug;

                $updateQuery = "UPDATE executives SET name = ?, slug = ?, type = ?, department = ?, role = ?, bio = ?, website = ?, social_links = ?, roll_no = ?, session = ?";
                $params = [$name, $slug, $type, $department, $role, $bio, $website, json_encode($socialLinks), $rollNo, $session];

                if ($profilePic) {
                    $updateQuery .= ", profile_pic = ?";
                    $params[] = $profilePic;
                }

                $updateQuery .= " WHERE id = ?";
                $params[] = $id;

                $stmt = $pdo->prepare($updateQuery);
                $stmt->execute($params);
                $_SESSION['success'] = "Executive updated successfully!";
            }
        } elseif ($action == 'delete') {
            $id = $_POST['id'];
            $stmt = $pdo->prepare("DELETE FROM executives WHERE id = ?");
            $stmt->execute([$id]);
            $_SESSION['success'] = "Executive deleted successfully!";
        } elseif ($action == 'reorder') {
            $order = json_decode($_POST['order'], true);
            if (json_last_error() !== JSON_ERROR_NONE) {
                error_log("JSON decode error: " . json_last_error_msg());
                exit('Invalid order data');
            }
            
            try {
                $pdo->beginTransaction();
                foreach ($order as $item) {
                    if (!isset($item['id']) || !isset($item['sort_order'])) {
                        throw new Exception("Invalid order item: " . print_r($item, true));
                    }
                    $stmt = $pdo->prepare("UPDATE executives SET sort_order = ? WHERE id = ?");
                    $stmt->execute([$item['sort_order'], $item['id']]);
                }
                $pdo->commit();
                exit('Order updated successfully');
            } catch (Exception $e) {
                $pdo->rollBack();
                error_log("Reorder error: " . $e->getMessage());
                exit('Error updating order');
            }
        } elseif ($action == 'archive_committee') {
            $archiveYear = isset($_POST['archive_year']) ? sanitize($_POST['archive_year']) : null;
            $selectedMembers = isset($_POST['selected_members']) ? json_decode($_POST['selected_members'], true) : [];
            
            if ($archiveYear) {
                // Archive current committee
                $stmt = $pdo->prepare("UPDATE executives SET archive_year = ? WHERE archive_year IS NULL");
                $stmt->execute([$archiveYear]);
                
                // Copy selected members to new committee
                if (!empty($selectedMembers)) {
                    $placeholders = str_repeat('?,', count($selectedMembers) - 1) . '?';
                    $stmt = $pdo->prepare("SELECT * FROM executives WHERE id IN ($placeholders)");
                    $stmt->execute($selectedMembers);
                    $membersToCopy = $stmt->fetchAll();
                    
                    foreach ($membersToCopy as $member) {
                        // Generate unique slug
                        $baseSlug = generateExecutiveSlug($member['name']);
                        $uniqueSlug = $baseSlug;
                        $counter = 1;
                        
                        // Check if slug exists and make it unique
                        while (true) {
                            $checkStmt = $pdo->prepare("SELECT COUNT(*) FROM executives WHERE slug = ?");
                            $checkStmt->execute([$uniqueSlug]);
                            if ($checkStmt->fetchColumn() == 0) {
                                break;
                            }
                            $uniqueSlug = $baseSlug . '-' . $counter;
                            $counter++;
                        }
                        
                        $stmt = $pdo->prepare("INSERT INTO executives (name, slug, type, department, role, bio, website, social_links, roll_no, session, profile_pic, sort_order, archive_year) 
                                             VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, (SELECT COALESCE(MAX(sort_order), 0) + 1 FROM executives e), NULL)");
                        $stmt->execute([
                            $member['name'],
                            $uniqueSlug,
                            $member['type'],
                            $member['department'],
                            $member['role'],
                            $member['bio'],
                            $member['website'],
                            $member['social_links'],
                            $member['roll_no'],
                            $member['session'],
                            $member['profile_pic']
                        ]);
                    }
                }
                
                $_SESSION['success'] = "Current committee archived for year $archiveYear";
                exit("Archived current committee for year $archiveYear");
            }
            http_response_code(400);
            exit("Archive year is required");
        } elseif ($action == 'restore_archives') {
            // Restore last archived committee only
            $stmt = $pdo->prepare("SELECT DISTINCT archive_year FROM executives WHERE archive_year IS NOT NULL ORDER BY archive_year DESC LIMIT 1");
            $stmt->execute();
            $lastYear = $stmt->fetchColumn();
            if ($lastYear) {
                $updateStmt = $pdo->prepare("UPDATE executives SET archive_year = NULL WHERE archive_year = ?");
                $updateStmt->execute([$lastYear]);
                $_SESSION['success'] = "Last archived committee restored successfully.";
                exit("Restored last archived committee.");
            } else {
                http_response_code(400);
                exit("No archived committees to restore.");
            }
        }
    }
}

$filterArchived = true; // Flag to filter archived executives

// Get archive year from URL parameter
$archiveYearFilter = isset($_GET['archive_year']) ? $_GET['archive_year'] : (isset($_GET['year']) ? $_GET['year'] : 'current');

// If archive_year parameter is used, redirect to the correct format
if (isset($_GET['archive_year']) && !isset($_GET['year'])) {
    $params = $_GET;
    unset($params['archive_year']);
    $params['year'] = $_GET['archive_year'];
    $redirectUrl = $_SERVER['PHP_SELF'] . '?' . http_build_query($params);
    header("Location: " . $redirectUrl);
    exit;
}

// Debug output
error_log("Archive Year Filter: " . $archiveYearFilter);

if ($archiveYearFilter === 'current') {
    $stmt = $pdo->prepare("SELECT * FROM executives WHERE archive_year IS NULL ORDER BY sort_order ASC, id ASC");
    $stmt->execute();
} else {
    $stmt = $pdo->prepare("SELECT * FROM executives WHERE archive_year = ? ORDER BY sort_order ASC, id ASC");
    $stmt->execute([$archiveYearFilter]);
}
$executives = $stmt->fetchAll();

// Debug output
error_log("Executives query result count: " . count($executives));
foreach ($executives as $exec) {
    error_log("Executive ID: " . $exec['id'] . ", Sort Order: " . $exec['sort_order'] . ", Archive Year: " . $exec['archive_year']);
}
?>

<div class="container px-6 mx-auto">
    <h2 class="my-6 text-2xl font-semibold text-gray-700">
        Manage Executives
        <?php if ($archiveYearFilter !== 'current'): ?>
        <span class="text-sm font-normal text-gray-500">(Archived Committee - <?php echo htmlspecialchars($archiveYearFilter); ?>)</span>
        <?php endif; ?>
    </h2>

    <?php include __DIR__ . '/../includes/alerts.php'; ?>

    <!-- Add Executive Button -->
<div class="mb-6 flex items-center justify-between">
    <div>
        <label for="committeeFilter" class="mr-2 font-semibold">Select Committee:</label>
        <select id="committeeFilter" class="px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-primary-500 focus:border-primary-500 dark:bg-gray-700 dark:border-gray-600 dark:text-white">
            <option value="current" <?php echo ($archiveYearFilter === 'current') ? 'selected' : ''; ?>>Current Committee</option>
            <?php
            $archiveStmt = $pdo->query("SELECT DISTINCT archive_year FROM executives WHERE archive_year IS NOT NULL ORDER BY archive_year DESC LIMIT 10");
            $archiveYears = $archiveStmt->fetchAll(PDO::FETCH_COLUMN);
            foreach ($archiveYears as $year) {
                $selected = ($archiveYearFilter == $year) ? 'selected' : '';
                echo "<option value=\"" . htmlspecialchars($year) . "\" $selected>Archived - $year</option>";
            }
            ?>
        </select>
        <button id="restoreArchivedBtn" class="ml-4 px-3 py-2 bg-yellow-500 text-white rounded hover:bg-yellow-600" title="Restore last archived committee">Restore Last Committee</button>
    </div>
    <div>
        <button onclick="showModal('add')" class="px-4 py-2 text-sm font-medium leading-5 text-white transition-colors duration-150 bg-purple-600 border border-transparent rounded-lg active:bg-purple-600 hover:bg-purple-700 focus:outline-none focus:shadow-outline-purple">
            Add Executive
        </button>
        <button id="addNewCommitteeBtn" class="ml-2 px-4 py-2 text-sm font-medium leading-5 text-white transition-colors duration-150 bg-green-600 border border-transparent rounded-lg active:bg-green-600 hover:bg-green-700 focus:outline-none focus:shadow-outline-green">
            Add New Committee
        </button>
    </div>
</div>

<script>
document.getElementById('committeeFilter').addEventListener('change', function() {
    const year = this.value;
    let url = window.location.pathname;
    if (year === 'current') {
        url = url.split('?')[0];
        window.location.href = url;
    } else {
        const params = new URLSearchParams(window.location.search);
        params.set('year', year);
        window.location.href = url + '?' + params.toString();
    }
});

document.getElementById('restoreArchivedBtn').addEventListener('click', function() {
    document.getElementById('restoreConfirmModal').classList.remove('hidden');
});
</script>

<!-- Archive Confirmation Modal -->
<div id="archiveConfirmModal" class="fixed inset-0 z-40 hidden overflow-y-auto">
    <div class="flex items-center justify-center min-h-screen px-4">
        <div class="bg-white rounded-lg shadow-lg max-w-md w-full p-6">
            <h3 class="text-lg font-semibold mb-4">Archive Current Committee</h3>
            <p class="mb-4">Are you sure you want to archive the current committee?</p>
            <label class="inline-flex items-center mb-4">
                <input type="checkbox" id="confirmArchiveCheckbox" class="form-checkbox h-5 w-5 text-green-600">
                <span class="ml-2">I confirm that I want to archive the current committee.</span>
            </label>
            <div class="flex justify-end space-x-4">
                <button id="archiveCancelBtn" class="px-4 py-2 bg-gray-300 rounded hover:bg-gray-400">Cancel</button>
                <button id="archiveNextBtn" class="px-4 py-2 bg-green-600 text-white rounded disabled:opacity-50" disabled>Next</button>
            </div>
        </div>
    </div>
</div>

<!-- Archive Year Input Modal -->
<div id="archiveYearModal" class="fixed inset-0 z-50 hidden overflow-y-auto">
    <div class="flex items-center justify-center min-h-screen px-4">
        <div class="bg-white rounded-lg shadow-lg max-w-md w-full p-6">
            <h3 class="text-lg font-semibold mb-4">Enter Archive Year</h3>
            <input type="number" id="archiveYearInput" min="1900" max="2100" placeholder="e.g. 2025" class="w-full px-3 py-2 border rounded mb-4" />
            <label for="archiveConfirmText" class="block mb-2 font-medium text-gray-700">Type "archive {year}" to confirm</label>
            <input type="text" id="archiveConfirmText" placeholder='e.g. archive 2025' class="w-full px-3 py-2 border rounded mb-4" disabled />
            <div class="flex justify-end space-x-4">
                <button id="archiveYearCancelBtn" class="px-4 py-2 bg-gray-300 rounded hover:bg-gray-400">Cancel</button>
                <button id="archiveYearConfirmBtn" class="px-4 py-2 bg-green-600 text-white rounded disabled:opacity-50" disabled>Confirm</button>
            </div>
        </div>
    </div>
</div>

<!-- Member Selection Modal -->
<div id="memberSelectionModal" class="fixed inset-0 z-50 hidden overflow-y-auto">
    <div class="flex items-center justify-center min-h-screen px-4">
        <div class="bg-white rounded-lg shadow-lg max-w-2xl w-full p-6">
            <h3 class="text-lg font-semibold mb-4">Select Members to Carry Over</h3>
            <div class="max-h-96 overflow-y-auto mb-4">
                <table class="w-full">
                    <thead>
                        <tr class="text-left border-b">
                            <th class="py-2">Select</th>
                            <th class="py-2">Profile</th>
                            <th class="py-2">Name</th>
                            <th class="py-2">Type</th>
                        </tr>
                    </thead>
                    <tbody id="memberSelectionList">
                        <?php foreach ($executives as $executive): ?>
                        <tr>
                            <td class="py-2">
                                <input type="checkbox" name="selected_members[]" value="<?php echo $executive['id']; ?>" class="member-checkbox">
                            </td>
                            <td class="py-2">
                                <img src="<?php echo $executive['profile_pic'] ? '../uploads/executives/' . $executive['profile_pic'] : '../assets/images/default-avatar.jpg'; ?>" 
                                     alt="Profile" class="w-8 h-8 rounded-full">
                            </td>
                            <td class="py-2"><?php echo htmlspecialchars($executive['name']); ?></td>
                            <td class="py-2"><?php echo ucfirst(htmlspecialchars($executive['type'])); ?></td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
            <div class="flex justify-end space-x-4">
                <button id="memberSelectionCancelBtn" class="px-4 py-2 bg-gray-300 rounded hover:bg-gray-400">Cancel</button>
                <button id="memberSelectionConfirmBtn" class="px-4 py-2 bg-green-600 text-white rounded">Confirm</button>
            </div>
        </div>
    </div>
</div>

<script>
const addNewCommitteeBtn = document.getElementById('addNewCommitteeBtn');
const archiveConfirmModal = document.getElementById('archiveConfirmModal');
const archiveCancelBtn = document.getElementById('archiveCancelBtn');
const confirmArchiveCheckbox = document.getElementById('confirmArchiveCheckbox');
const archiveNextBtn = document.getElementById('archiveNextBtn');
const archiveYearModal = document.getElementById('archiveYearModal');
const archiveYearCancelBtn = document.getElementById('archiveYearCancelBtn');
const archiveYearInput = document.getElementById('archiveYearInput');
const archiveConfirmText = document.getElementById('archiveConfirmText');
const archiveYearConfirmBtn = document.getElementById('archiveYearConfirmBtn');

addNewCommitteeBtn.addEventListener('click', function() {
    // Show the archive confirmation modal first
    document.getElementById('archiveConfirmModal').classList.remove('hidden');
});

archiveCancelBtn.addEventListener('click', function() {
    document.getElementById('archiveConfirmModal').classList.add('hidden');
    document.getElementById('confirmArchiveCheckbox').checked = false;
    document.getElementById('archiveNextBtn').disabled = true;
});

confirmArchiveCheckbox.addEventListener('change', function() {
    document.getElementById('archiveNextBtn').disabled = !this.checked;
});

archiveNextBtn.addEventListener('click', function() {
    document.getElementById('archiveConfirmModal').classList.add('hidden');
    document.getElementById('archiveYearModal').classList.remove('hidden');
});

archiveYearCancelBtn.addEventListener('click', function() {
    document.getElementById('archiveYearModal').classList.add('hidden');
    document.getElementById('archiveYearInput').value = '';
    document.getElementById('archiveConfirmText').value = '';
    document.getElementById('archiveYearConfirmBtn').disabled = true;
});

archiveYearInput.addEventListener('input', function() {
    const val = this.value;
    document.getElementById('archiveConfirmText').value = '';
    document.getElementById('archiveConfirmText').disabled = !(val && val.length === 4 && !isNaN(val));
    document.getElementById('archiveYearConfirmBtn').disabled = true;
});

archiveConfirmText.addEventListener('input', function() {
    const year = document.getElementById('archiveYearInput').value;
    const expectedText = `archive ${year}`;
    document.getElementById('archiveYearConfirmBtn').disabled = this.value.trim().toLowerCase() !== expectedText.toLowerCase();
});

archiveYearConfirmBtn.addEventListener('click', function() {
    const year = document.getElementById('archiveYearInput').value;
    if (!year) return;

    // Show member selection modal
    document.getElementById('archiveYearModal').classList.add('hidden');
    document.getElementById('memberSelectionModal').classList.remove('hidden');
});

// Member selection modal handlers
document.getElementById('memberSelectionCancelBtn').addEventListener('click', function() {
    document.getElementById('memberSelectionModal').classList.add('hidden');
});

document.getElementById('memberSelectionConfirmBtn').addEventListener('click', function() {
    const year = document.getElementById('archiveYearInput').value;
    const selectedMembers = Array.from(document.querySelectorAll('.member-checkbox:checked'))
        .map(checkbox => checkbox.value);

    fetch(window.location.href, {
        method: 'POST',
        headers: {'Content-Type': 'application/x-www-form-urlencoded'},
        body: `action=archive_committee&archive_year=${encodeURIComponent(year)}&selected_members=${JSON.stringify(selectedMembers)}`
    }).then(response => response.text())
      .then(data => {
          showNotification(`Current committee archived for year ${year}. Selected members have been carried over to the new committee.`, 'success');
          setTimeout(() => location.reload(), 1500);
      }).catch(err => {
          showNotification('Error archiving committee: ' + err, 'error');
      });
});

function updateDepartments() {
    const type = document.getElementById('type').value;
    const departmentSelect = document.getElementById('department');
    const studentFields = document.getElementById('studentFields');
    
    // Clear existing options
    departmentSelect.innerHTML = '';
    
    // Show/hide student specific fields
    studentFields.style.display = type === 'student' ? 'block' : 'none';
    
    // Get departments based on type
    const departments = type === 'teacher' 
        ? <?php echo json_encode(getTeacherDepartments()); ?>
        : <?php echo json_encode(getStudentDepartments()); ?>;
    
    // Add new options
    departments.forEach(dept => {
        const option = document.createElement('option');
        option.value = dept;
        option.textContent = dept;
        departmentSelect.appendChild(option);
    });
}

function showModal(action, executive = null) {
    document.getElementById('executiveModal').classList.remove('hidden');
    document.getElementById('formAction').value = action;
    
    if (action === 'edit' && executive) {
        document.getElementById('executiveId').value = executive.id;
        document.getElementById('name').value = executive.name;
        document.getElementById('currentSlug').value = executive.slug;
        document.getElementById('originalName').value = executive.name;
        document.getElementById('type').value = executive.type;
        document.getElementById('role').value = executive.role;
        document.getElementById('bio').value = executive.bio || '';
        document.getElementById('website').value = executive.website || '';
        
        updateDepartments();
        document.getElementById('department').value = executive.department;
        
        if (executive.type === 'student') {
            document.getElementById('rollNo').value = executive.roll_no || '';
            document.getElementById('session').value = executive.session || '';
        }
        
        const socialLinks = JSON.parse(executive.social_links || '{}');
        document.getElementById('facebook').value = socialLinks.facebook || '';
        document.getElementById('twitter').value = socialLinks.twitter || '';
        document.getElementById('linkedin').value = socialLinks.linkedin || '';
        document.getElementById('instagram').value = socialLinks.instagram || '';
    } else {
        document.getElementById('executiveForm').reset();
        updateDepartments();
    }
}

function hideModal() {
    document.getElementById('executiveModal').classList.add('hidden');
}

function deleteExecutive(id) {
    // Create and show custom delete confirmation modal
    const modal = document.createElement('div');
    modal.className = 'fixed inset-0 z-50 overflow-y-auto';
    modal.innerHTML = `
        <div class="flex items-center justify-center min-h-screen px-4">
            <div class="bg-white rounded-lg shadow-lg max-w-md w-full p-6">
                <div class="flex items-center justify-center mb-4">
                    <svg class="h-12 w-12 text-red-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z"/>
                    </svg>
                </div>
                <h3 class="text-lg font-semibold text-center mb-4">Confirm Delete</h3>
                <p class="text-gray-600 text-center mb-6">Are you sure you want to delete this executive?</p>
                <div class="flex justify-center space-x-4">
                    <button id="deleteCancelBtn" class="px-4 py-2 bg-gray-300 rounded hover:bg-gray-400 focus:outline-none focus:ring-2 focus:ring-gray-500">
                        Cancel
                    </button>
                    <button id="deleteConfirmBtn" class="px-4 py-2 bg-red-500 text-white rounded hover:bg-red-600 focus:outline-none focus:ring-2 focus:ring-red-500">
                        Delete
                    </button>
                </div>
            </div>
        </div>
    `;
    
    document.body.appendChild(modal);
    
    // Handle cancel
    modal.querySelector('#deleteCancelBtn').addEventListener('click', function() {
        modal.remove();
    });
    
    // Handle confirm
    modal.querySelector('#deleteConfirmBtn').addEventListener('click', function() {
        modal.remove();
        const form = document.createElement('form');
        form.method = 'POST';
        form.innerHTML = `
            <input type="hidden" name="action" value="delete">
            <input type="hidden" name="id" value="${id}">
        `;
        document.body.appendChild(form);
        form.submit();
    });
}

function moveExecutive(id, direction) {
    const row = document.querySelector(`tr[data-id="${id}"]`);
    const rows = Array.from(document.querySelectorAll('#executivesList tr'));
    const currentIndex = rows.indexOf(row);
    
    if (direction === 'up' && currentIndex > 0) {
        // Move up
        const prevRow = rows[currentIndex - 1];
        row.parentNode.insertBefore(row, prevRow);
        updateOrder();
    } else if (direction === 'down' && currentIndex < rows.length - 1) {
        // Move down
        const nextRow = rows[currentIndex + 1];
        row.parentNode.insertBefore(nextRow, row);
        updateOrder();
    }
}

function updateOrder() {
    const rows = Array.from(document.querySelectorAll('#executivesList tr'));
    const newOrder = rows.map((row, index) => ({
        id: row.dataset.id,
        sort_order: index + 1
    }));
    
    console.log('Updating order:', newOrder); // Debug log
    
    // Create a FormData object
    const formData = new FormData();
    formData.append('action', 'reorder');
    formData.append('order', JSON.stringify(newOrder));
    
    fetch(window.location.href, {
        method: 'POST',
        body: formData
    }).then(response => {
        if (!response.ok) {
            throw new Error('Network response was not ok: ' + response.status);
        }
        return response.text();
    }).then(data => {
        console.log('Server response:', data); // Debug log
        showNotification('Order updated successfully', 'success');
        // Force a page reload to ensure the order is reflected
        setTimeout(() => location.reload(), 500);
    }).catch(err => {
        console.error('Error:', err); // Debug log
        showNotification('Error updating order: ' + err, 'error');
    });
}
</script>

    <!-- Executives Table -->
    <div class="w-full overflow-hidden rounded-lg shadow-xs">
        <div class="w-full overflow-x-auto">
            <table class="w-full whitespace-no-wrap" id="executivesTable">
                <thead>
                    <tr class="text-xs font-semibold tracking-wide text-left text-gray-500 uppercase border-b bg-gray-50">
                        <th class="px-4 py-3">Name</th>
                        <th class="px-4 py-3">Type</th>
                        <th class="px-4 py-3">Department/Class</th>
                        <th class="px-4 py-3">Role</th>
                        <th class="px-4 py-3">Actions</th>
                    </tr>
                </thead>
                <tbody class="bg-white divide-y" id="executivesList">
<?php foreach ($executives as $executive): ?>
<tr class="text-gray-700 hover:bg-gray-50 group" data-id="<?php echo $executive['id']; ?>">
    <td class="px-4 py-3">
        <div class="flex items-center text-sm">
            <div class="relative hidden w-8 h-8 mr-3 rounded-full md:block">
                <img class="object-cover w-full h-full rounded-full" 
                     src="<?php echo $executive['profile_pic'] ? '../uploads/executives/' . $executive['profile_pic'] : '../assets/images/default-avatar.jpg'; ?>" 
                     alt="Executive profile picture" 
                     loading="lazy" />
            </div>
            <div>
                <p class="font-semibold"><?php echo htmlspecialchars($executive['name']); ?></p>
                <p class="text-xs text-gray-600"><?php echo htmlspecialchars($executive['slug']); ?></p>
            </div>
        </div>
    </td>
    <td class="px-4 py-3 text-sm">
        <?php echo ucfirst(htmlspecialchars($executive['type'])); ?>
    </td>
    <td class="px-4 py-3 text-sm">
        <?php echo htmlspecialchars($executive['department']); ?>
    </td>
    <td class="px-4 py-3 text-sm">
        <?php echo htmlspecialchars($executive['role']); ?>
    </td>
    <td class="px-4 py-3">
        <div class="flex items-center space-x-4 text-sm">
            <?php if (empty($executive['archive_year'])): ?>
            <div class="flex items-center space-x-2">
                <button onclick="moveExecutive(<?php echo $executive['id']; ?>, 'up')" 
                        class="sort-btn opacity-0 group-hover:opacity-100 transition-opacity duration-200 p-1 text-gray-500 hover:text-purple-600 focus:outline-none">
                    <svg class="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 15l7-7 7 7" />
                    </svg>
                </button>
                <button onclick="moveExecutive(<?php echo $executive['id']; ?>, 'down')" 
                        class="sort-btn opacity-0 group-hover:opacity-100 transition-opacity duration-200 p-1 text-gray-500 hover:text-purple-600 focus:outline-none">
                    <svg class="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 9l-7 7-7-7" />
                    </svg>
                </button>
                <button onclick="showModal('edit', <?php echo htmlspecialchars(json_encode($executive)); ?>)" 
                        class="flex items-center justify-between px-2 py-2 text-sm font-medium leading-5 text-purple-600 rounded-lg focus:outline-none focus:shadow-outline-gray">
                    <svg class="w-5 h-5" fill="currentColor" viewBox="0 0 20 20">
                        <path d="M13.586 3.586a2 2 0 112.828 2.828l-.793.793-2.828-2.828.793-.793zM11.379 5.793L3 14.172V17h2.828l8.38-8.379-2.83-2.828z"></path>
                    </svg>
                </button>
                <button onclick="deleteExecutive(<?php echo $executive['id']; ?>)"
                        class="flex items-center justify-between px-2 py-2 text-sm font-medium leading-5 text-purple-600 rounded-lg focus:outline-none focus:shadow-outline-gray">
                    <svg class="w-5 h-5" fill="currentColor" viewBox="0 0 20 20">
                        <path fill-rule="evenodd" d="M9 2a1 1 0 00-.894.553L7.382 4H4a1 1 0 000 2v10a2 2 0 002 2h8a2 2 0 002-2V6a1 1 0 100-2h-3.382l-.724-1.447A1 1 0 0011 2H9zM7 8a1 1 0 012 0v6a1 1 0 11-2 0V8zm5-1a1 1 0 00-1 1v6a1 1 0 102 0V8a1 1 0 00-1-1z" clip-rule="evenodd"></path>
                    </svg>
                </button>
            </div>
            <?php else: ?>
            <span class="text-gray-400 italic text-sm">Archived</span>
            <?php endif; ?>
        </div>
    </td>
</tr>
<?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<!-- Modal -->
<div id="executiveModal" class="fixed inset-0 z-30 hidden overflow-y-auto">
    <div class="flex items-end justify-center min-h-screen px-4 pt-4 pb-20 text-center sm:block sm:p-0">
        <div class="fixed inset-0 transition-opacity" aria-hidden="true">
            <div class="absolute inset-0 bg-gray-500 opacity-75"></div>
        </div>
        <div class="inline-block overflow-hidden text-left align-bottom transition-all transform bg-white rounded-lg shadow-xl sm:my-8 sm:align-middle sm:max-w-lg sm:w-full">
            <form id="executiveForm" method="POST" enctype="multipart/form-data">
                <input type="hidden" name="action" id="formAction">
                <input type="hidden" name="id" id="executiveId">
                <input type="hidden" name="current_slug" id="currentSlug">
                <input type="hidden" name="original_name" id="originalName">
                
                <div class="px-4 pt-5 pb-4 bg-white sm:p-6 sm:pb-4">
                    <div class="mb-4">
                        <label class="block mb-2 text-sm font-medium text-gray-700">Name</label>
                        <input type="text" name="name" id="name" required 
                               class="w-full px-3 py-2 leading-tight text-gray-700 border rounded shadow appearance-none focus:outline-none focus:shadow-outline">
                    </div>
                    
                    <div class="mb-4">
                        <label class="block mb-2 text-sm font-medium text-gray-700">Type</label>
                        <select name="type" id="type" required onchange="updateDepartments()"
                                class="w-full px-3 py-2 leading-tight text-gray-700 border rounded shadow appearance-none focus:outline-none focus:shadow-outline">
                            <option value="teacher">Teacher</option>
                            <option value="student">Student</option>
                        </select>
                    </div>
                    
                    <div class="mb-4">
                        <label class="block mb-2 text-sm font-medium text-gray-700">Department/Class</label>
                        <select name="department" id="department" required
                                class="w-full px-3 py-2 leading-tight text-gray-700 border rounded shadow appearance-none focus:outline-none focus:shadow-outline">
                        </select>
                    </div>
                    
                    <div id="studentFields" class="hidden">
                        <div class="mb-4">
                            <label class="block mb-2 text-sm font-medium text-gray-700">Roll No</label>
                            <input type="text" name="roll_no" id="rollNo"
                                   class="w-full px-3 py-2 leading-tight text-gray-700 border rounded shadow appearance-none focus:outline-none focus:shadow-outline">
                        </div>
                        
                        <div class="mb-4">
                            <label class="block mb-2 text-sm font-medium text-gray-700">Session</label>
                            <input type="text" name="session" id="session"
                                   class="w-full px-3 py-2 leading-tight text-gray-700 border rounded shadow appearance-none focus:outline-none focus:shadow-outline">
                        </div>
                    </div>
                    
                    <div class="mb-4">
                        <label class="block mb-2 text-sm font-medium text-gray-700">Role</label>
                        <input type="text" name="role" id="role" required
                               class="w-full px-3 py-2 leading-tight text-gray-700 border rounded shadow appearance-none focus:outline-none focus:shadow-outline">
                    </div>
                    
                    <div class="mb-4">
                        <label class="block mb-2 text-sm font-medium text-gray-700">Profile Picture</label>
                        <input type="file" name="profile_pic" id="profilePic" accept="image/*"
                               class="w-full px-3 py-2 leading-tight text-gray-700 border rounded shadow appearance-none focus:outline-none focus:shadow-outline">
                    </div>
                    
                    <div class="mb-4">
                        <label class="block mb-2 text-sm font-medium text-gray-700">Bio</label>
                        <textarea name="bio" id="bio" rows="3"
                                  class="w-full px-3 py-2 leading-tight text-gray-700 border rounded shadow appearance-none focus:outline-none focus:shadow-outline"></textarea>
                    </div>
                    
                    <div class="mb-4">
                        <label class="block mb-2 text-sm font-medium text-gray-700">Website</label>
                        <input type="url" name="website" id="website"
                               class="w-full px-3 py-2 leading-tight text-gray-700 border rounded shadow appearance-none focus:outline-none focus:shadow-outline">
                    </div>
                    
                    <div class="mb-4">
                        <label class="block mb-2 text-sm font-medium text-gray-700">Social Media Links</label>
                        <input type="url" name="facebook" id="facebook" placeholder="Facebook"
                               class="w-full px-3 py-2 mb-2 leading-tight text-gray-700 border rounded shadow appearance-none focus:outline-none focus:shadow-outline">
                        <input type="url" name="twitter" id="twitter" placeholder="Twitter"
                               class="w-full px-3 py-2 mb-2 leading-tight text-gray-700 border rounded shadow appearance-none focus:outline-none focus:shadow-outline">
                        <input type="url" name="linkedin" id="linkedin" placeholder="LinkedIn"
                               class="w-full px-3 py-2 mb-2 leading-tight text-gray-700 border rounded shadow appearance-none focus:outline-none focus:shadow-outline">
                        <input type="url" name="instagram" id="instagram" placeholder="Instagram"
                               class="w-full px-3 py-2 leading-tight text-gray-700 border rounded shadow appearance-none focus:outline-none focus:shadow-outline">
                    </div>
                </div>
                
                <div class="px-4 py-3 bg-gray-50 sm:px-6 sm:flex sm:flex-row-reverse">
                    <button type="submit"
                            class="inline-flex justify-center w-full px-4 py-2 text-base font-medium text-white bg-purple-600 border border-transparent rounded-md shadow-sm hover:bg-purple-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-purple-500 sm:ml-3 sm:w-auto sm:text-sm">
                        Save
                    </button>
                    <button type="button" onclick="hideModal()"
                            class="inline-flex justify-center w-full px-4 py-2 mt-3 text-base font-medium text-gray-700 bg-white border border-gray-300 rounded-md shadow-sm hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 sm:mt-0 sm:ml-3 sm:w-auto sm:text-sm">
                        Cancel
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<div id="notification-container" class="fixed top-4 right-4 z-50"></div>

<style>
.notification {
    position: fixed;
    top: 1rem;
    right: 1rem;
    z-index: 50;
    padding: 1rem;
    border-radius: 0.5rem;
    box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1), 0 2px 4px -1px rgba(0, 0, 0, 0.06);
    transform: translateX(0);
    transition: all 0.3s ease-in-out;
    background-color: white !important;
    animation: slideIn 0.3s ease-out forwards;
}

.notification.success {
    border-left: 4px solid #10B981;
    color: #065F46;
}

.notification.error {
    border-left: 4px solid #EF4444;
    color: #991B1B;
}

.notification.warning {
    border-left: 4px solid #F59E0B;
    color: #92400E;
}

@keyframes slideIn {
    from {
        transform: translateX(100%);
        opacity: 0;
    }
    to {
        transform: translateX(0);
        opacity: 1;
    }
}

@keyframes slideOut {
    from {
        transform: translateX(0);
        opacity: 1;
    }
    to {
        transform: translateX(100%);
        opacity: 0;
    }
}
</style>

<script>
// Notification system
function showNotification(message, type = 'success') {
    const container = document.getElementById('notification-container');
    const notification = document.createElement('div');
    notification.className = `notification ${type}`;
    notification.innerHTML = `
        <div class="flex items-center">
            <div class="flex-shrink-0">
                ${type === 'success' ? 
                    '<svg class="h-6 w-6 text-green-500" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"/></svg>' :
                    type === 'error' ?
                    '<svg class="h-6 w-6 text-red-500" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"/></svg>' :
                    '<svg class="h-6 w-6 text-yellow-500" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z"/></svg>'
                }
            </div>
            <div class="ml-3">
                <p class="text-sm font-medium">${message}</p>
            </div>
            <div class="ml-auto pl-3">
                <div class="-mx-1.5 -my-1.5">
                    <button onclick="this.parentElement.parentElement.parentElement.parentElement.remove()" class="inline-flex rounded-md p-1.5 focus:outline-none focus:ring-2 focus:ring-offset-2">
                        <svg class="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"/>
                        </svg>
                    </button>
                </div>
            </div>
        </div>
    `;
    
    container.appendChild(notification);
    
    // Auto remove after 5 seconds
    setTimeout(() => {
        notification.style.animation = 'slideOut 0.3s ease-in forwards';
        setTimeout(() => notification.remove(), 300);
    }, 5000);
}

function updateDepartments() {
    const type = document.getElementById('type').value;
    const departmentSelect = document.getElementById('department');
    const studentFields = document.getElementById('studentFields');
    
    // Clear existing options
    departmentSelect.innerHTML = '';
    
    // Show/hide student specific fields
    studentFields.style.display = type === 'student' ? 'block' : 'none';
    
    // Get departments based on type
    const departments = type === 'teacher' 
        ? <?php echo json_encode(getTeacherDepartments()); ?>
        : <?php echo json_encode(getStudentDepartments()); ?>;
    
    // Add new options
    departments.forEach(dept => {
        const option = document.createElement('option');
        option.value = dept;
        option.textContent = dept;
        departmentSelect.appendChild(option);
    });
}

function showModal(action, executive = null) {
    document.getElementById('executiveModal').classList.remove('hidden');
    document.getElementById('formAction').value = action;
    
    if (action === 'edit' && executive) {
        document.getElementById('executiveId').value = executive.id;
        document.getElementById('name').value = executive.name;
        document.getElementById('currentSlug').value = executive.slug;
        document.getElementById('originalName').value = executive.name;
        document.getElementById('type').value = executive.type;
        document.getElementById('role').value = executive.role;
        document.getElementById('bio').value = executive.bio || '';
        document.getElementById('website').value = executive.website || '';
        
        updateDepartments();
        document.getElementById('department').value = executive.department;
        
        if (executive.type === 'student') {
            document.getElementById('rollNo').value = executive.roll_no || '';
            document.getElementById('session').value = executive.session || '';
        }
        
        const socialLinks = JSON.parse(executive.social_links || '{}');
        document.getElementById('facebook').value = socialLinks.facebook || '';
        document.getElementById('twitter').value = socialLinks.twitter || '';
        document.getElementById('linkedin').value = socialLinks.linkedin || '';
        document.getElementById('instagram').value = socialLinks.instagram || '';
    } else {
        document.getElementById('executiveForm').reset();
        updateDepartments();
    }
}

function hideModal() {
    document.getElementById('executiveModal').classList.add('hidden');
}

function deleteExecutive(id) {
    // Create and show custom delete confirmation modal
    const modal = document.createElement('div');
    modal.className = 'fixed inset-0 z-50 overflow-y-auto';
    modal.innerHTML = `
        <div class="flex items-center justify-center min-h-screen px-4">
            <div class="bg-white rounded-lg shadow-lg max-w-md w-full p-6">
                <div class="flex items-center justify-center mb-4">
                    <svg class="h-12 w-12 text-red-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z"/>
                    </svg>
                </div>
                <h3 class="text-lg font-semibold text-center mb-4">Confirm Delete</h3>
                <p class="text-gray-600 text-center mb-6">Are you sure you want to delete this executive?</p>
                <div class="flex justify-center space-x-4">
                    <button id="deleteCancelBtn" class="px-4 py-2 bg-gray-300 rounded hover:bg-gray-400 focus:outline-none focus:ring-2 focus:ring-gray-500">
                        Cancel
                    </button>
                    <button id="deleteConfirmBtn" class="px-4 py-2 bg-red-500 text-white rounded hover:bg-red-600 focus:outline-none focus:ring-2 focus:ring-red-500">
                        Delete
                    </button>
                </div>
            </div>
        </div>
    `;
    
    document.body.appendChild(modal);
    
    // Handle cancel
    modal.querySelector('#deleteCancelBtn').addEventListener('click', function() {
        modal.remove();
    });
    
    // Handle confirm
    modal.querySelector('#deleteConfirmBtn').addEventListener('click', function() {
        modal.remove();
        const form = document.createElement('form');
        form.method = 'POST';
        form.innerHTML = `
            <input type="hidden" name="action" value="delete">
            <input type="hidden" name="id" value="${id}">
        `;
        document.body.appendChild(form);
        form.submit();
    });
}

// Initialize departments on load
updateDepartments();
</script>

<!-- Custom Confirmation Modal -->
<div id="restoreConfirmModal" class="fixed inset-0 z-50 hidden overflow-y-auto">
    <div class="flex items-center justify-center min-h-screen px-4">
        <div class="bg-white rounded-lg shadow-lg max-w-md w-full p-6">
            <div class="flex items-center justify-center mb-4">
                <svg class="h-12 w-12 text-yellow-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z"/>
                </svg>
            </div>
            <h3 class="text-lg font-semibold text-center mb-4">Confirm Restore</h3>
            <p class="text-gray-600 text-center mb-4">Type "restore committee" to confirm</p>
            <input type="text" id="restoreConfirmText" placeholder="Type 'restore committee'" 
                   class="w-full px-3 py-2 border rounded mb-4 focus:outline-none focus:ring-2 focus:ring-yellow-500">
            <div class="flex justify-center space-x-4">
                <button id="restoreConfirmCancelBtn" class="px-4 py-2 bg-gray-300 rounded hover:bg-gray-400 focus:outline-none focus:ring-2 focus:ring-gray-500">
                    Cancel
                </button>
                <button id="restoreConfirmBtn" class="px-4 py-2 bg-yellow-500 text-white rounded hover:bg-yellow-600 focus:outline-none focus:ring-2 focus:ring-yellow-500 disabled:opacity-50" disabled>
                    Restore
                </button>
            </div>
        </div>
    </div>
</div>

<script>
// Update restore functionality
document.getElementById('restoreArchivedBtn').addEventListener('click', function() {
    document.getElementById('restoreConfirmModal').classList.remove('hidden');
});

document.getElementById('restoreConfirmCancelBtn').addEventListener('click', function() {
    document.getElementById('restoreConfirmModal').classList.add('hidden');
    document.getElementById('restoreConfirmText').value = '';
    document.getElementById('restoreConfirmBtn').disabled = true;
});

document.getElementById('restoreConfirmText').addEventListener('input', function() {
    const expectedText = 'restore committee';
    document.getElementById('restoreConfirmBtn').disabled = 
        this.value.trim().toLowerCase() !== expectedText.toLowerCase();
});

document.getElementById('restoreConfirmBtn').addEventListener('click', function() {
    document.getElementById('restoreConfirmModal').classList.add('hidden');
    
    fetch(window.location.href, {
        method: 'POST',
        headers: {'Content-Type': 'application/x-www-form-urlencoded'},
        body: 'action=restore_archives'
    }).then(response => response.text())
      .then(data => {
          showNotification('Last archived committee restored successfully.', 'success');
          setTimeout(() => location.reload(), 1500);
      }).catch(err => {
          showNotification('Error restoring archive: ' + err, 'error');
      });
});
</script>