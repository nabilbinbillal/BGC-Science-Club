<?php
require_once '../config/auth.php';
require_once '../config/db.php';
require_once 'includes/auth_check.php';

$page = 'members';
$page_title = 'Manage Members';

// Handle sorting
$sort_field = isset($_GET['sort']) ? $_GET['sort'] : 'created_at';
$sort_order = isset($_GET['order']) ? $_GET['order'] : 'DESC';
$valid_sort_fields = ['name', 'department', 'member_id', 'created_at', 'status', 'sort_order'];

if (!in_array($sort_field, $valid_sort_fields)) {
    $sort_field = 'created_at';
}

// Handle status updates
if (isset($_POST['action']) && isset($_POST['member_id'])) {
    $member_id = $_POST['member_id'];
    $action = $_POST['action'];
    
    if ($action === 'approve') {
        $stmt = $pdo->prepare("UPDATE members SET status = 'approved' WHERE member_id = ?");
        $stmt->execute([$member_id]);
    } elseif ($action === 'reject') {
        $stmt = $pdo->prepare("UPDATE members SET status = 'rejected' WHERE member_id = ?");
        $stmt->execute([$member_id]);
    } elseif ($action === 'delete') {
        $stmt = $pdo->prepare("DELETE FROM members WHERE member_id = ?");
        $stmt->execute([$member_id]);
    } elseif ($action === 'update_sort_order') {
        $sort_order_value = (int)$_POST['sort_order'];
        $stmt = $pdo->prepare("UPDATE members SET sort_order = ? WHERE member_id = ?");
        $stmt->execute([$sort_order_value, $member_id]);
    }
}

// Get members with pagination
$page_number = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$items_per_page = 10;
$offset = ($page_number - 1) * $items_per_page;

// Get total count
$count_stmt = $pdo->query("SELECT COUNT(*) FROM members");
$total_members = $count_stmt->fetchColumn();
$total_pages = ceil($total_members / $items_per_page);

// Get members
$query = "SELECT * FROM members ORDER BY $sort_field $sort_order LIMIT ? OFFSET ?";
$stmt = $pdo->prepare($query);
$stmt->execute([$items_per_page, $offset]);
$members = $stmt->fetchAll();

include 'includes/header.php';
?>

<div class="container px-6 py-8 mx-auto">
    <div class="mb-8">
        <h1 class="text-2xl font-semibold text-gray-900 dark:text-white">Manage Members</h1>
        <p class="mt-2 text-gray-600 dark:text-gray-400">View and manage club members.</p>
    </div>

    <!-- Members Table -->
    <div class="bg-white dark:bg-gray-800 shadow rounded-lg overflow-hidden">
        <div class="overflow-x-auto">
            <table class="min-w-full divide-y divide-gray-200 dark:divide-gray-700">
                <thead class="bg-gray-50 dark:bg-gray-700">
                    <tr>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">
                            <a href="?sort=member_id&order=<?php echo $sort_field === 'member_id' && $sort_order === 'ASC' ? 'DESC' : 'ASC'; ?>" 
                               class="flex items-center space-x-1 hover:text-gray-700 dark:hover:text-gray-200">
                                <span>Member ID</span>
                                <?php if ($sort_field === 'member_id'): ?>
                                <i class="fas fa-sort-<?php echo $sort_order === 'ASC' ? 'up' : 'down'; ?>"></i>
                                <?php endif; ?>
                            </a>
                        </th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">
                            <a href="?sort=name&order=<?php echo $sort_field === 'name' && $sort_order === 'ASC' ? 'DESC' : 'ASC'; ?>"
                               class="flex items-center space-x-1 hover:text-gray-700 dark:hover:text-gray-200">
                                <span>Name</span>
                                <?php if ($sort_field === 'name'): ?>
                                <i class="fas fa-sort-<?php echo $sort_order === 'ASC' ? 'up' : 'down'; ?>"></i>
                                <?php endif; ?>
                            </a>
                        </th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">
                            <a href="?sort=department&order=<?php echo $sort_field === 'department' && $sort_order === 'ASC' ? 'DESC' : 'ASC'; ?>"
                               class="flex items-center space-x-1 hover:text-gray-700 dark:hover:text-gray-200">
                                <span>Department</span>
                                <?php if ($sort_field === 'department'): ?>
                                <i class="fas fa-sort-<?php echo $sort_order === 'ASC' ? 'up' : 'down'; ?>"></i>
                                <?php endif; ?>
                            </a>
                        </th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">Contact</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">
                            <a href="?sort=status&order=<?php echo $sort_field === 'status' && $sort_order === 'ASC' ? 'DESC' : 'ASC'; ?>"
                               class="flex items-center space-x-1 hover:text-gray-700 dark:hover:text-gray-200">
                                <span>Status</span>
                                <?php if ($sort_field === 'status'): ?>
                                <i class="fas fa-sort-<?php echo $sort_order === 'ASC' ? 'up' : 'down'; ?>"></i>
                                <?php endif; ?>
                            </a>
                        </th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">
                            <a href="?sort=sort_order&order=<?php echo $sort_field === 'sort_order' && $sort_order === 'ASC' ? 'DESC' : 'ASC'; ?>"
                               class="flex items-center space-x-1 hover:text-gray-700 dark:hover:text-gray-200">
                                <span>Display Order</span>
                                <?php if ($sort_field === 'sort_order'): ?>
                                <i class="fas fa-sort-<?php echo $sort_order === 'ASC' ? 'up' : 'down'; ?>"></i>
                                <?php endif; ?>
                            </a>
                        </th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">Actions</th>
                    </tr>
                </thead>
                <tbody class="bg-white dark:bg-gray-800 divide-y divide-gray-200 dark:divide-gray-700">
                    <?php foreach ($members as $member): ?>
                    <tr class="hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors">
                        <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900 dark:text-white">
                            <?php echo htmlspecialchars($member['member_id']); ?>
                        </td>
                        <td class="px-6 py-4 whitespace-nowrap">
                            <div class="flex items-center">
                                <?php if ($member['image']): ?>
                                <img class="h-10 w-10 rounded-full object-cover" 
                                     src="/uploads/members/<?php echo $member['image']; ?>" 
                                     alt="<?php echo htmlspecialchars($member['name']); ?>">
                                <?php else: ?>
                                <div class="h-10 w-10 rounded-full bg-gray-200 dark:bg-gray-700 flex items-center justify-center">
                                    <i class="fas fa-user text-gray-400"></i>
                                </div>
                                <?php endif; ?>
                                <div class="ml-4">
                                    <div class="text-sm font-medium text-gray-900 dark:text-white">
                                        <?php echo htmlspecialchars($member['name']); ?>
                                    </div>
                                    <div class="text-sm text-gray-500 dark:text-gray-400">
                                        <?php echo htmlspecialchars($member['roll_no']); ?>
                                    </div>
                                </div>
                            </div>
                        </td>
                        <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900 dark:text-white">
                            <?php echo htmlspecialchars($member['department']); ?>
                        </td>
                        <td class="px-6 py-4 whitespace-nowrap">
                            <div class="text-sm text-gray-900 dark:text-white"><?php echo htmlspecialchars($member['email']); ?></div>
                            <div class="text-sm text-gray-500 dark:text-gray-400"><?php echo htmlspecialchars($member['phone']); ?></div>
                        </td>
                        <td class="px-6 py-4 whitespace-nowrap">
                            <span class="px-2 inline-flex text-xs leading-5 font-semibold rounded-full 
                                <?php echo $member['status'] === 'approved' 
                                    ? 'bg-green-100 text-green-800 dark:bg-green-800 dark:text-green-100'
                                    : ($member['status'] === 'pending' 
                                        ? 'bg-yellow-100 text-yellow-800 dark:bg-yellow-800 dark:text-yellow-100'
                                        : 'bg-red-100 text-red-800 dark:bg-red-800 dark:text-red-100'); ?>">
                                <?php echo ucfirst($member['status']); ?>
                            </span>
                        </td>
                        <td class="px-6 py-4 whitespace-nowrap">
                            <form method="POST" class="flex items-center space-x-2">
                                <input type="hidden" name="member_id" value="<?php echo $member['member_id']; ?>">
                                <input type="hidden" name="action" value="update_sort_order">
                                <input type="number" name="sort_order" value="<?php echo $member['sort_order'] ?? 0; ?>"
                                       class="w-20 px-2 py-1 text-sm border rounded-md dark:bg-gray-700 dark:border-gray-600 dark:text-white"
                                       onchange="this.form.submit()">
                            </form>
                        </td>
                        <td class="px-6 py-4 whitespace-nowrap text-sm font-medium space-x-2">
                            <?php if ($member['status'] === 'pending'): ?>
                            <form method="POST" class="inline">
                                <input type="hidden" name="member_id" value="<?php echo $member['member_id']; ?>">
                                <input type="hidden" name="action" value="approve">
                                <button type="submit" class="text-green-600 hover:text-green-900 dark:hover:text-green-400">
                                    Approve
                                </button>
                            </form>
                            <form method="POST" class="inline">
                                <input type="hidden" name="member_id" value="<?php echo $member['member_id']; ?>">
                                <input type="hidden" name="action" value="reject">
                                <button type="submit" class="text-red-600 hover:text-red-900 dark:hover:text-red-400">
                                    Reject
                                </button>
                            </form>
                            <?php endif; ?>
                            <form method="POST" class="inline" onsubmit="return confirm('Are you sure you want to delete this member?');">
                                <input type="hidden" name="member_id" value="<?php echo $member['member_id']; ?>">
                                <input type="hidden" name="action" value="delete">
                                <button type="submit" class="text-red-600 hover:text-red-900 dark:hover:text-red-400">
                                    Delete
                                </button>
                            </form>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
        
        <!-- Pagination -->
        <?php if ($total_pages > 1): ?>
        <div class="bg-white dark:bg-gray-800 px-4 py-3 flex items-center justify-between border-t border-gray-200 dark:border-gray-700 sm:px-6">
            <div class="flex-1 flex justify-between sm:hidden">
                <?php if ($page_number > 1): ?>
                <a href="?page=<?php echo $page_number - 1; ?>&sort=<?php echo $sort_field; ?>&order=<?php echo $sort_order; ?>" 
                   class="relative inline-flex items-center px-4 py-2 border border-gray-300 text-sm font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50">
                    Previous
                </a>
                <?php endif; ?>
                <?php if ($page_number < $total_pages): ?>
                <a href="?page=<?php echo $page_number + 1; ?>&sort=<?php echo $sort_field; ?>&order=<?php echo $sort_order; ?>" 
                   class="ml-3 relative inline-flex items-center px-4 py-2 border border-gray-300 text-sm font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50">
                    Next
                </a>
                <?php endif; ?>
            </div>
            <div class="hidden sm:flex-1 sm:flex sm:items-center sm:justify-between">
                <div>
                    <p class="text-sm text-gray-700 dark:text-gray-300">
                        Showing <span class="font-medium"><?php echo $offset + 1; ?></span> to 
                        <span class="font-medium"><?php echo min($offset + $items_per_page, $total_members); ?></span> of 
                        <span class="font-medium"><?php echo $total_members; ?></span> results
                    </p>
                </div>
                <div>
                    <nav class="relative z-0 inline-flex rounded-md shadow-sm -space-x-px" aria-label="Pagination">
                        <?php for ($i = 1; $i <= $total_pages; $i++): ?>
                        <a href="?page=<?php echo $i; ?>&sort=<?php echo $sort_field; ?>&order=<?php echo $sort_order; ?>" 
                           class="relative inline-flex items-center px-4 py-2 border border-gray-300 dark:border-gray-600 text-sm font-medium 
                                  <?php echo $i === $page_number 
                                      ? 'z-10 bg-primary-50 border-primary-500 text-primary-600 dark:bg-primary-900 dark:text-primary-200' 
                                      : 'bg-white dark:bg-gray-800 text-gray-500 dark:text-gray-400 hover:bg-gray-50 dark:hover:bg-gray-700'; ?>">
                            <?php echo $i; ?>
                        </a>
                        <?php endfor; ?>
                    </nav>
                </div>
            </div>
        </div>
        <?php endif; ?>
    </div>
</div>

<?php include 'includes/footer.php'; ?> 