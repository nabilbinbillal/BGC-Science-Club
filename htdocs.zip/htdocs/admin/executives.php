<?php
require_once '../config/auth.php';
require_once '../config/db.php';
require_once 'includes/auth_check.php';

$page = 'executives';
$page_title = 'Manage Executives';

// Handle sorting
$sort_field = isset($_GET['sort']) ? $_GET['sort'] : 'sort_order';
$sort_order = isset($_GET['order']) ? $_GET['order'] : 'ASC';
$valid_sort_fields = ['name', 'position', 'department', 'sort_order'];

if (!in_array($sort_field, $valid_sort_fields)) {
    $sort_field = 'sort_order';
}

// Handle status updates and sorting
if (isset($_POST['action']) && isset($_POST['id'])) {
    $id = (int)$_POST['id'];
    $action = $_POST['action'];
    
    if ($action === 'delete') {
        // Delete profile picture if exists
        $stmt = $pdo->prepare("SELECT profile_pic FROM executives WHERE id = ?");
        $stmt->execute([$id]);
        $exec = $stmt->fetch();
        
        if ($exec && $exec['profile_pic']) {
            $file_path = '../uploads/executives/' . $exec['profile_pic'];
            if (file_exists($file_path)) {
                unlink($file_path);
            }
        }
        
        $stmt = $pdo->prepare("DELETE FROM executives WHERE id = ?");
        $stmt->execute([$id]);
    } elseif ($action === 'update_sort_order') {
        $sort_order_value = (int)$_POST['sort_order'];
        $stmt = $pdo->prepare("UPDATE executives SET sort_order = ? WHERE id = ?");
        $stmt->execute([$sort_order_value, $id]);
    }
}

// Get executives with pagination
$page_number = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$items_per_page = 10;
$offset = ($page_number - 1) * $items_per_page;

// Get total count
$count_stmt = $pdo->query("SELECT COUNT(*) FROM executives");
$total_executives = $count_stmt->fetchColumn();
$total_pages = ceil($total_executives / $items_per_page);

// Get executives
$query = "SELECT * FROM executives ORDER BY $sort_field $sort_order LIMIT ? OFFSET ?";
$stmt = $pdo->prepare($query);
$stmt->execute([$items_per_page, $offset]);
$executives = $stmt->fetchAll();

include 'includes/header.php';
?>

<div class="container px-6 py-8 mx-auto">
    <div class="mb-8 flex justify-between items-center">
        <div>
            <h1 class="text-2xl font-semibold text-gray-900 dark:text-white">Manage Executives</h1>
            <p class="mt-2 text-gray-600 dark:text-gray-400">View and manage club executives.</p>
        </div>
        <a href="add_executive.php" class="bg-primary-600 text-white px-4 py-2 rounded-md hover:bg-primary-700 transition-colors">
            Add Executive
        </a>
    </div>

    <!-- Executives Table -->
    <div class="bg-white dark:bg-gray-800 shadow rounded-lg overflow-hidden">
        <div class="overflow-x-auto">
            <table class="min-w-full divide-y divide-gray-200 dark:divide-gray-700">
                <thead class="bg-gray-50 dark:bg-gray-700">
                    <tr>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">
                            <a href="?sort=name&order=<?php echo $sort_field === 'name' && $sort_order === 'ASC' ? 'DESC' : 'ASC'; ?>"
                               class="flex items-center space-x-1 hover:text-gray-700 dark:hover:text-gray-200">
                                <span>Name</span>
                                <?php if ($sort_field === 'name'): ?>
                                <i class="fas fa-sort-<?php echo $sort_order === 'ASC' ? 'up' : 'down'; ?>"></i>
                                <?php endif; ?>
                            </a>
                        </th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">
                            <a href="?sort=position&order=<?php echo $sort_field === 'position' && $sort_order === 'ASC' ? 'DESC' : 'ASC'; ?>"
                               class="flex items-center space-x-1 hover:text-gray-700 dark:hover:text-gray-200">
                                <span>Position</span>
                                <?php if ($sort_field === 'position'): ?>
                                <i class="fas fa-sort-<?php echo $sort_order === 'ASC' ? 'up' : 'down'; ?>"></i>
                                <?php endif; ?>
                            </a>
                        </th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">
                            <a href="?sort=department&order=<?php echo $sort_field === 'department' && $sort_order === 'ASC' ? 'DESC' : 'ASC'; ?>"
                               class="flex items-center space-x-1 hover:text-gray-700 dark:hover:text-gray-200">
                                <span>Department</span>
                                <?php if ($sort_field === 'department'): ?>
                                <i class="fas fa-sort-<?php echo $sort_order === 'ASC' ? 'up' : 'down'; ?>"></i>
                                <?php endif; ?>
                            </a>
                        </th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">Contact</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">
                            <a href="?sort=sort_order&order=<?php echo $sort_field === 'sort_order' && $sort_order === 'ASC' ? 'DESC' : 'ASC'; ?>"
                               class="flex items-center space-x-1 hover:text-gray-700 dark:hover:text-gray-200">
                                <span>Display Order</span>
                                <?php if ($sort_field === 'sort_order'): ?>
                                <i class="fas fa-sort-<?php echo $sort_order === 'ASC' ? 'up' : 'down'; ?>"></i>
                                <?php endif; ?>
                            </a>
                        </th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">Actions</th>
                    </tr>
                </thead>
                <tbody class="bg-white dark:bg-gray-800 divide-y divide-gray-200 dark:divide-gray-700">
                    <?php foreach ($executives as $executive): ?>
                    <tr class="hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors">
                        <td class="px-6 py-4 whitespace-nowrap">
                            <div class="flex items-center">
                                <?php if ($executive['profile_pic']): ?>
                                <img class="h-10 w-10 rounded-full object-cover" 
                                     src="/uploads/executives/<?php echo $executive['profile_pic']; ?>" 
                                     alt="<?php echo htmlspecialchars($executive['name']); ?>">
                                <?php else: ?>
                                <div class="h-10 w-10 rounded-full bg-gray-200 dark:bg-gray-700 flex items-center justify-center">
                                    <i class="fas fa-user text-gray-400"></i>
                                </div>
                                <?php endif; ?>
                                <div class="ml-4">
                                    <div class="text-sm font-medium text-gray-900 dark:text-white">
                                        <?php echo htmlspecialchars($executive['name']); ?>
                                    </div>
                                </div>
                            </div>
                        </td>
                        <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900 dark:text-white">
                            <?php echo htmlspecialchars($executive['position']); ?>
                        </td>
                        <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900 dark:text-white">
                            <?php echo htmlspecialchars($executive['department']); ?>
                        </td>
                        <td class="px-6 py-4 whitespace-nowrap">
                            <div class="text-sm text-gray-900 dark:text-white"><?php echo htmlspecialchars($executive['email']); ?></div>
                            <div class="text-sm text-gray-500 dark:text-gray-400"><?php echo htmlspecialchars($executive['phone']); ?></div>
                        </td>
                        <td class="px-6 py-4 whitespace-nowrap">
                            <form method="POST" class="flex items-center space-x-2">
                                <input type="hidden" name="id" value="<?php echo $executive['id']; ?>">
                                <input type="hidden" name="action" value="update_sort_order">
                                <input type="number" name="sort_order" value="<?php echo $executive['sort_order'] ?? 0; ?>"
                                       class="w-20 px-2 py-1 text-sm border rounded-md dark:bg-gray-700 dark:border-gray-600 dark:text-white"
                                       onchange="this.form.submit()">
                            </form>
                        </td>
                        <td class="px-6 py-4 whitespace-nowrap text-sm font-medium space-x-2">
                            <a href="edit_executive.php?id=<?php echo $executive['id']; ?>" 
                               class="text-primary-600 hover:text-primary-900 dark:hover:text-primary-400">
                                Edit
                            </a>
                            <form method="POST" class="inline" onsubmit="return confirm('Are you sure you want to delete this executive?');">
                                <input type="hidden" name="id" value="<?php echo $executive['id']; ?>">
                                <input type="hidden" name="action" value="delete">
                                <button type="submit" class="text-red-600 hover:text-red-900 dark:hover:text-red-400">
                                    Delete
                                </button>
                            </form>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
        
        <!-- Pagination -->
        <?php if ($total_pages > 1): ?>
        <div class="bg-white dark:bg-gray-800 px-4 py-3 flex items-center justify-between border-t border-gray-200 dark:border-gray-700 sm:px-6">
            <div class="flex-1 flex justify-between sm:hidden">
                <?php if ($page_number > 1): ?>
                <a href="?page=<?php echo $page_number - 1; ?>&sort=<?php echo $sort_field; ?>&order=<?php echo $sort_order; ?>" 
                   class="relative inline-flex items-center px-4 py-2 border border-gray-300 text-sm font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50">
                    Previous
                </a>
                <?php endif; ?>
                <?php if ($page_number < $total_pages): ?>
                <a href="?page=<?php echo $page_number + 1; ?>&sort=<?php echo $sort_field; ?>&order=<?php echo $sort_order; ?>" 
                   class="ml-3 relative inline-flex items-center px-4 py-2 border border-gray-300 text-sm font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50">
                    Next
                </a>
                <?php endif; ?>
            </div>
            <div class="hidden sm:flex-1 sm:flex sm:items-center sm:justify-between">
                <div>
                    <p class="text-sm text-gray-700 dark:text-gray-300">
                        Showing <span class="font-medium"><?php echo $offset + 1; ?></span> to 
                        <span class="font-medium"><?php echo min($offset + $items_per_page, $total_executives); ?></span> of 
                        <span class="font-medium"><?php echo $total_executives; ?></span> results
                    </p>
                </div>
                <div>
                    <nav class="relative z-0 inline-flex rounded-md shadow-sm -space-x-px" aria-label="Pagination">
                        <?php for ($i = 1; $i <= $total_pages; $i++): ?>
                        <a href="?page=<?php echo $i; ?>&sort=<?php echo $sort_field; ?>&order=<?php echo $sort_order; ?>" 
                           class="relative inline-flex items-center px-4 py-2 border border-gray-300 dark:border-gray-600 text-sm font-medium 
                                  <?php echo $i === $page_number 
                                      ? 'z-10 bg-primary-50 border-primary-500 text-primary-600 dark:bg-primary-900 dark:text-primary-200' 
                                      : 'bg-white dark:bg-gray-800 text-gray-500 dark:text-gray-400 hover:bg-gray-50 dark:hover:bg-gray-700'; ?>">
                            <?php echo $i; ?>
                        </a>
                        <?php endfor; ?>
                    </nav>
                </div>
            </div>
        </div>
        <?php endif; ?>
    </div>
</div>

<?php include 'includes/footer.php'; ?> 