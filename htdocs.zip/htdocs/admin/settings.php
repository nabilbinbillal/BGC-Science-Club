<?php
session_start();
require_once '../config/db.php';
require_once '../includes/functions.php';

// Check if admin is logged in
if (!isset($_SESSION['admin_id'])) {
    header('Location: login.php');
    exit();
}

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        // Update reCAPTCHA settings
        $recaptcha_enabled = isset($_POST['recaptcha_enabled']) ? 1 : 0;
        
        $stmt = $pdo->prepare("UPDATE settings SET recaptcha_enabled = ? WHERE id = 1");
        if ($stmt->execute([$recaptcha_enabled])) {
            $success = "Settings updated successfully.";
        } else {
            $error = "Failed to update settings.";
        }
    } catch (PDOException $e) {
        $error = "An error occurred while updating settings.";
        error_log($e->getMessage());
    }
}

// Get current settings
$stmt = $pdo->query("SELECT * FROM settings LIMIT 1");
$settings = $stmt->fetch();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Settings - Admin Panel</title>
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
</head>
<body class="bg-gray-100">
    <?php include 'includes/header.php'; ?>

    <div class="container mx-auto px-4 py-8">
        <div class="max-w-2xl mx-auto">
            <h1 class="text-2xl font-bold mb-8">Website Settings</h1>

            <?php if (isset($success)): ?>
            <div class="bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded mb-4">
                <?php echo $success; ?>
            </div>
            <?php endif; ?>

            <?php if (isset($error)): ?>
            <div class="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded mb-4">
                <?php echo $error; ?>
            </div>
            <?php endif; ?>

            <form method="POST" class="bg-white shadow-md rounded px-8 pt-6 pb-8 mb-4">
                <div class="mb-6">
                    <h2 class="text-xl font-semibold mb-4">Security Settings</h2>
                    
                    <div class="flex items-center mb-4">
                        <input type="checkbox" id="recaptcha_enabled" name="recaptcha_enabled" 
                               class="mr-2" <?php echo $settings['recaptcha_enabled'] ? 'checked' : ''; ?>>
                        <label for="recaptcha_enabled" class="text-gray-700">
                            Enable CAPTCHA Verification
                        </label>
                    </div>
                    <p class="text-sm text-gray-600">
                        When enabled, users will need to complete a CAPTCHA verification on forms.
                    </p>
                </div>

                <div class="flex items-center justify-between">
                    <button type="submit" class="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded focus:outline-none focus:shadow-outline">
                        Save Settings
                    </button>
                </div>
            </form>
        </div>
    </div>

    <?php include 'includes/footer.php'; ?>
</body>
</html> 