<?php
// Generate a unique member ID
function generateMemberId() {
    global $pdo;
    
    $year = date('y');
    $prefix = "BGC-$year-";
    
    // Get the last member ID
    $stmt = $pdo->query("SELECT member_id FROM members WHERE member_id LIKE '$prefix%' ORDER BY id DESC LIMIT 1");
    $lastId = $stmt->fetch(PDO::FETCH_COLUMN);
    
    if ($lastId) {
        // Extract the number part and increment
        $lastNum = intval(substr($lastId, strlen($prefix)));
        $newNum = $lastNum + 1;
    } else {
        // Start with 1 if no existing IDs
        $newNum = 1;
    }
    
    // Format with leading zeros (4 digits)
    return $prefix . str_pad($newNum, 4, '0', STR_PAD_LEFT);
}

// Get department/class options
function getDepartmentOptions() {
    return [
        'Intermediate 1st Year',
        'Intermediate 2nd Year',
        'Physics',
        'Chemistry',
        'Botany',
        'Zoology',
        'Mathematics'
    ];
}

// Get role options
function getRoleOptions() {
    return [
        'member' => 'Member',
        'executive' => 'Executive'
    ];
}

// Get position options for executives
function getPositionOptions() {
    return [
        'President',
        'Vice President',
        'General Secretary',
        'Joint Secretary',
        'Treasurer',
        'Organizing Secretary',
        'Office Secretary',
        'Publication Secretary',
        'Executive Member'
    ];
}

// Check if user is logged in
function isLoggedIn() {
    return isset($_SESSION['admin_id']);
}

// Check if user is a superadmin
function isSuperAdmin() {
    return isset($_SESSION['admin_role']) && $_SESSION['admin_role'] == 'superadmin';
}

// Get avatar URL based on gender
function getAvatarUrl($gender, $image = null) {
    if ($image && file_exists('uploads/members/' . $image)) {
        return 'uploads/members/' . $image;
    }
    
    if ($gender == 'female') {
        return 'assets/images/default-avatar.jpg';
    }
    
    return 'assets/images/default-avatar.jpg';
}

// Get current page name
function getCurrentPage() {
    return isset($_GET['page']) ? $_GET['page'] : 'home';
}

// Format date for display
function formatDate($date) {
    return date('F j, Y', strtotime($date));
}

// Sanitize input data
function sanitize($data) {
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    return $data;
}

// Get teacher department options
function getTeacherDepartments() {
    return [
        'Physics',
        'Chemistry',
        'Botany',
        'Zoology',
        'Mathematics'
    ];
}

// Get student department/class options
function getStudentDepartments() {
    return [
        'Intermediate 1st Year',
        'Intermediate 2nd Year',
        'Physics',
        'Chemistry',
        'Botany',
        'Zoology',
        'Mathematics'
    ];
}

// Generate a unique slug for executives
function generateExecutiveSlug($name) {
    global $pdo;
    
    // Convert name to lowercase and replace spaces with hyphens
    $slug = strtolower(trim(preg_replace('/[^A-Za-z0-9-]+/', '-', $name)));
    
    // Check if slug exists
    $stmt = $pdo->prepare("SELECT COUNT(*) FROM executives WHERE slug = ?");
    $stmt->execute([$slug]);
    $count = $stmt->fetchColumn();
    
    // If slug exists, append number
    if ($count > 0) {
        $i = 1;
        do {
            $newSlug = $slug . "-" . $i;
            $stmt->execute([$newSlug]);
            $count = $stmt->fetchColumn();
            $i++;
        } while ($count > 0);
        return $newSlug;
    }
    
    return $slug;
}

// Get executive type options
function getExecutiveTypes() {
    return [
        'teacher' => 'Teacher',
        'student' => 'Student'
    ];
}

// Get all departments based on executive type
function getDepartmentsByType($type) {
    return $type === 'teacher' ? getTeacherDepartments() : getStudentDepartments();
}

// Format social media links
function formatSocialLinks($links) {
    if (empty($links)) return [];
    return is_array($links) ? $links : json_decode($links, true);
}