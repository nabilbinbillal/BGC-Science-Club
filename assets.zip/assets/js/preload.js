// Preload critical resources
function preloadCriticalResources() {
    // Preload fonts
    const fontPreloads = [
        { href: 'https://fonts.gstatic.com/s/poppins/v20/pxiEyp8kv8JHgFVrJJfecg.woff2', as: 'font', type: 'font/woff2', crossorigin: true },
        { href: 'https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/webfonts/fa-solid-900.woff2', as: 'font', type: 'font/woff2', crossorigin: true }
    ];

    fontPreloads.forEach(font => {
        const link = document.createElement('link');
        link.rel = 'preload';
        link.href = font.href;
        link.as = font.as;
        link.type = font.type;
        if (font.crossorigin) link.crossOrigin = 'anonymous';
        document.head.appendChild(link);
    });

    // Preload critical images
    const imagePreloads = [
        { href: '/assets/images/logo.webp', as: 'image', type: 'image/webp' },
        { href: '/assets/images/hero-image.webp', as: 'image', type: 'image/webp' }
    ];

    imagePreloads.forEach(img => {
        const link = document.createElement('link');
        link.rel = 'preload';
        link.href = img.href;
        link.as = img.as;
        if (img.type) link.type = img.type;
        document.head.appendChild(link);
    });
}

// Load non-critical CSS asynchronously
function loadNonCriticalCSS() {
    const links = [
        'https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css',
        'https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css',
        '/assets/css/style.css'
    ];

    links.forEach(href => {
        const link = document.createElement('link');
        link.rel = 'stylesheet';
        link.href = href;
        link.media = 'print';
        link.onload = () => { link.media = 'all'; };
        document.head.appendChild(link);
    });
}

// Load Google Fonts asynchronously
function loadGoogleFonts() {
    const link = document.createElement('link');
    link.href = 'https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap';
    link.rel = 'stylesheet';
    link.media = 'print';
    link.onload = () => { link.media = 'all'; };
    document.head.appendChild(link);
}

// Initialize optimizations when DOM is loaded
if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', initOptimizations);
} else {
    initOptimizations();
}

function initOptimizations() {
    preloadCriticalResources();
    loadNonCriticalCSS();
    loadGoogleFonts();
}
