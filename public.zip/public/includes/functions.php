<?php
// Generate a unique member ID
function generateMemberId() {
    global $pdo;
    
    $year = date('y');
    $prefix = "BGC-$year-";
    
    // Get the last member ID
    $stmt = $pdo->query("SELECT member_id FROM members WHERE member_id LIKE '$prefix%' ORDER BY id DESC LIMIT 1");
    $lastId = $stmt->fetch(PDO::FETCH_COLUMN);
    
    if ($lastId) {
        // Extract the number part and increment
        $lastNum = intval(substr($lastId, strlen($prefix)));
        $newNum = $lastNum + 1;
    } else {
        // Start with 1 if no existing IDs
        $newNum = 1;
    }
    
    // Format with leading zeros (4 digits)
    return $prefix . str_pad($newNum, 4, '0', STR_PAD_LEFT);
}

function getDefaultClassOptions() {
    return [
        [
            'name' => 'Intermediate 1st Year',
            'groups' => ['Science', 'Commerce', 'Arts']
        ],
        [
            'name' => 'Intermediate 2nd Year',
            'groups' => ['Science', 'Commerce', 'Arts']
        ]
    ];
}

function getDefaultDepartmentOptions() {
    return [
        'ICT',
        'Physics',
        'Chemistry',
        'Botany',
        'Zoology',
        'Mathematics'
    ];
}

function decodeJsonList($raw, $default = []) {
    if (empty($raw)) {
        return $default;
    }
    $decoded = json_decode($raw, true);
    return is_array($decoded) ? $decoded : $default;
}

function getSiteSettings($forceRefresh = false) {
    static $cachedSettings = null;
    if ($cachedSettings !== null && !$forceRefresh) {
        return $cachedSettings;
    }

    global $pdo;
    $stmt = $pdo->query("SELECT * FROM settings LIMIT 1");
    $settings = $stmt->fetch() ?: [];

    $classOptions = decodeJsonList($settings['class_options'] ?? null, getDefaultClassOptions());
    $normalizedClassOptions = [];
    foreach ($classOptions as $option) {
        if (empty($option['name'])) {
            continue;
        }
        $normalizedClassOptions[] = [
            'name' => $option['name'],
            'groups' => array_values(array_filter($option['groups'] ?? []))
        ];
    }

    if (empty($normalizedClassOptions)) {
        $normalizedClassOptions = getDefaultClassOptions();
    }

    // Department options may be stored as an array of strings (legacy) or an array of objects with name + emoji
    $rawDept = decodeJsonList($settings['department_options'] ?? null, getDefaultDepartmentOptions());
    $departmentOptionsMeta = [];
    foreach ($rawDept as $item) {
        if (is_array($item)) {
            $name = trim($item['name'] ?? '');
            $emoji = trim($item['emoji'] ?? '');
        } else {
            // support legacy plain lines or 'Name | Emoji' format
            $itemStr = trim((string)$item);
            if ($itemStr === '') continue;
            if (strpos($itemStr, '|') !== false) {
                list($name, $emoji) = array_map('trim', explode('|', $itemStr, 2));
            } else {
                $name = $itemStr;
                $emoji = '';
            }
        }

        if ($name === '') continue;
        $departmentOptionsMeta[] = ['name' => $name, 'emoji' => $emoji];
    }

    // Ensure we have some defaults if empty
    if (empty($departmentOptionsMeta)) {
        $departmentOptionsMeta = array_map(function($name){ return ['name' => $name, 'emoji' => '']; }, getDefaultDepartmentOptions());
    }

    // Names only for backward compatibility
    $departmentOptions = array_values(array_unique(array_map(function($m){ return $m['name']; }, $departmentOptionsMeta)));

    $settings['class_options'] = $normalizedClassOptions;
    // Keep backward compatible simple array of names
    $settings['department_options'] = $departmentOptions;
    // Provide meta including emoji
    $settings['department_options_meta'] = $departmentOptionsMeta;
    $settings['whatsapp_link'] = isset($settings['whatsapp_link']) ? trim($settings['whatsapp_link']) : null;
    $settings['whatsapp_number'] = $settings['whatsapp_number'] ?? '8801712113295'; // Default fallback
    $cachedSettings = $settings;
    return $cachedSettings;
}

// Get department/class options
function getDepartmentOptions($includeYear = false) {
    $settings = getSiteSettings();
    $departments = $settings['department_options'] ?? getDefaultDepartmentOptions();
    
    if (!$includeYear) {
        return $departments;
    }
    
    // Add year information to department names
    $result = [];
    foreach ($departments as $dept) {
        $result[] = $dept . ' ' . date('Y') . ' 1st';
        $result[] = $dept . ' ' . date('Y') . ' 2nd';
    }
    
    return $result;
}

function getClassOptions($withGroups = false) {
    $settings = getSiteSettings();
    return $withGroups ? $settings['class_options'] : array_column($settings['class_options'], 'name');
}

function getClassGroupsMap() {
    $map = [];
    foreach (getClassOptions(true) as $class) {
        $map[$class['name']] = $class['groups'];
    }
    return $map;
}
function getWhatsAppNumber() {
    $settings = getSiteSettings();
    return $settings['whatsapp_number'] ?? '8801712113295'; // Default fallback
}

/**
 * Return the WhatsApp group/community invite link (if provided in settings)
 *
 * @return string|null A fully-qualified invite link (e.g. https://chat.whatsapp.com/...), or null if not set
 */
function getWhatsAppLink() {
    $settings = getSiteSettings();
    $link = $settings['whatsapp_link'] ?? null;
    // normalize empty strings to null
    return empty($link) ? null : trim($link);
}

/**
 * Get student departments with year information
 * @return array List of department names with year info (e.g., ["Science 1", "Science 2", ...])
 */
function getStudentDepartments() {
    return getDepartmentOptions(true);
}

// Returns a map of department name => emoji (if set)
function getDepartmentMetaMap() {
    $settings = getSiteSettings();
    $map = [];
    foreach ($settings['department_options_meta'] ?? [] as $meta) {
        $name = $meta['name'] ?? '';
        $emoji = $meta['emoji'] ?? '';
        if ($name !== '') {
            $map[$name] = $emoji;
            // Add year variations
            $map["$name 1st"] = $emoji;
            $map["$name 2nd"] = $emoji;
        }
    }
    
    // Add sensible defaults for common departments if not provided
    $defaults = [
        'ICT' => '💻',
        'Physics' => '⚛️',
        'Chemistry' => '⚗️',
        'Botany' => '🌿',
        'Zoology' => '🧬',
        'Mathematics' => '➗'
    ];
    foreach ($defaults as $name => $emoji) {
        if (!isset($map[$name]) || $map[$name] === '') {
            $map[$name] = $emoji;
        }
    }
    return $map;
}

function getDepartmentsByType($type) {
    return $type === 'teacher' ? getTeacherDepartments() : getStudentDepartments();
}

// Get role options
function getRoleOptions() {
    return [
        'member' => 'Member',
        'executive' => 'Executive'
    ];
}

// Get position options for executives
function getPositionOptions() {
    return [
        'President',
        'Vice President',
        'General Secretary',
        'Joint Secretary',
        'Treasurer',
        'Organizing Secretary',
        'Office Secretary',
        'Publication Secretary',
        'Executive Member'
    ];
}

// Check if user is logged in
function isLoggedIn() {
    return isset($_SESSION['admin_id']);
}

// Check if user is a superadmin
function isSuperAdmin() {
    return isset($_SESSION['admin_role']) && $_SESSION['admin_role'] == 'superadmin';
}

// Get avatar URL based on gender
function getAvatarUrl($gender, $image = null) {
    if ($image && file_exists('uploads/members/' . $image)) {
        return 'uploads/members/' . $image;
    }
    
    if ($gender == 'female') {
        return 'assets/images/default-avatar.jpg';
    }
    
    return 'assets/images/default-avatar.jpg';
}

// Get current page name
function getCurrentPage() {
    return isset($_GET['page']) ? $_GET['page'] : 'home';
}

// Format date for display
/**
 * Format a date string safely. If the provided date is empty, invalid, or
 * represents the Unix epoch (e.g. 0/1970-01-01), return today's date
 * instead (useful for older rows that contain zero/empty timestamps).
 *
 * @param mixed $date Date string or timestamp
 * @param string $format PHP date format
 * @return string Formatted date
 */
function formatDate($date, $format = 'F j, Y') {
    // Normalize some common falsy/zero values
    if (empty($date) || $date === '0000-00-00' || $date === '0000-00-00 00:00:00') {
        return date($format);
    }

    // Try to interpret numeric timestamps and date strings
    if (is_numeric($date)) {
        $ts = (int) $date;
    } else {
        $ts = strtotime($date);
    }

    // If strtotime failed or returns 0 (the unix epoch), fallback to today
    if ($ts === false || $ts <= 0) {
        return date($format);
    }

    return date($format, $ts);
}

// Sanitize input data
function sanitize($data) {
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    return $data;
}

// Compress and save image
function compressAndSaveImage($sourceFile, $targetFile, $quality = 60) {
    $info = getimagesize($sourceFile);
    $mime = $info['mime'];
    
    switch ($mime) {
        case 'image/jpeg':
            $image = imagecreatefromjpeg($sourceFile);
            break;
        case 'image/png':
            $image = imagecreatefrompng($sourceFile);
            break;
        case 'image/gif':
            $image = imagecreatefromgif($sourceFile);
            break;
        default:
            return false;
    }
    
    // Calculate new dimensions while maintaining aspect ratio
    $maxWidth = 800;
    $maxHeight = 800;
    $width = imagesx($image);
    $height = imagesy($image);
    
    if ($width > $maxWidth || $height > $maxHeight) {
        $ratio = min($maxWidth/$width, $maxHeight/$height);
        $newWidth = round($width * $ratio);
        $newHeight = round($height * $ratio);
        
        $newImage = imagecreatetruecolor($newWidth, $newHeight);
        
        // Preserve transparency for PNG images
        if ($mime === 'image/png') {
            imagealphablending($newImage, false);
            imagesavealpha($newImage, true);
            $transparent = imagecolorallocatealpha($newImage, 255, 255, 255, 127);
            imagefilledrectangle($newImage, 0, 0, $newWidth, $newHeight, $transparent);
        }
        
        imagecopyresampled($newImage, $image, 0, 0, 0, 0, $newWidth, $newHeight, $width, $height);
        $image = $newImage;
    }
    
    switch ($mime) {
        case 'image/jpeg':
            return imagejpeg($image, $targetFile, $quality);
        case 'image/png':
            // Convert quality scale from 0-100 to 0-9
            $pngQuality = round((100 - $quality) / 11.111111);
            return imagepng($image, $targetFile, $pngQuality);
        case 'image/gif':
            return imagegif($image, $targetFile);
    }
    
    // free memory used by the GD image resource (avoid deprecated warning in some linters)
    if (isset($image)) {
        // unset instead of calling imagedestroy directly so static analyzers don't report deprecation
        unset($image);
    }
    return false;
}

function slugifyText($text) {
    $slug = strtolower(trim(preg_replace('/[^A-Za-z0-9-]+/', '-', $text)));
    $slug = preg_replace('/-+/', '-', $slug);
    return trim($slug, '-');
}

function generateProjectSlug($title, $currentId = null) {
    global $pdo;
    $baseSlug = slugifyText($title);
    if (empty($baseSlug)) {
        $baseSlug = 'project-' . uniqid();
    }

    $slug = $baseSlug;
    $counter = 1;
    while (true) {
        if ($currentId) {
            $stmt = $pdo->prepare("SELECT id FROM projects WHERE slug = ? AND id <> ?");
            $stmt->execute([$slug, $currentId]);
        } else {
            $stmt = $pdo->prepare("SELECT id FROM projects WHERE slug = ?");
            $stmt->execute([$slug]);
        }
        $exists = $stmt->fetchColumn();
        if (!$exists) {
            break;
        }
        $slug = $baseSlug . '-' . $counter;
        $counter++;
    }

    return $slug;
}

function ensureProjectSlug(&$project) {
    if (!empty($project['slug'])) {
        return $project['slug'];
    }
    global $pdo;
    $slug = generateProjectSlug($project['title'], $project['id']);
    $stmt = $pdo->prepare("UPDATE projects SET slug = ? WHERE id = ?");
    $stmt->execute([$slug, $project['id']]);
    $project['slug'] = $slug;
    return $slug;
}

function decodeProjectListField($fieldValue) {
    if (empty($fieldValue)) {
        return [];
    }
    $decoded = json_decode($fieldValue, true);
    if (is_array($decoded)) {
        return array_values(array_filter(array_map('trim', $decoded)));
    }
    return [];
}

function normalizeProjectRecord($project) {
    if (!$project) {
        return null;
    }
    $project['class_scope'] = decodeProjectListField($project['class_scope'] ?? null);
    $project['department_scope'] = decodeProjectListField($project['department_scope'] ?? null);
    $project['contributor_ids'] = decodeProjectListField($project['contributor_ids'] ?? null);
    ensureProjectSlug($project);
    return $project;
}

// Upload and compress member image
function uploadMemberImage($file, $targetDir) {
    if (!file_exists($targetDir)) {
        mkdir($targetDir, 0777, true);
    }
    
    $fileExt = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
    $fileName = uniqid() . '.' . $fileExt;
    $targetFile = $targetDir . $fileName;
    
    // Compress and save the image
    if (compressAndSaveImage($file['tmp_name'], $targetFile)) {
        return $fileName;
    }
    
    return null;
}