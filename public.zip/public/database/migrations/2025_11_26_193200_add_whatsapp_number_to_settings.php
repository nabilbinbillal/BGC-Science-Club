<?php

$db = new PDO('sqlite:' . __DIR__ . '/../../database/database.sqlite');

// Enable foreign key constraints
$db->exec('PRAGMA foreign_keys = ON;');

// Begin transaction
$db->beginTransaction();

try {
    // Check if whatsapp_number column exists
    $stmt = $db->query("PRAGMA table_info(settings)");
    $columns = $stmt->fetchAll(PDO::FETCH_COLUMN, 1);
    
    if (!in_array('whatsapp_number', $columns)) {
        // Add whatsapp_number column
        $db->exec("ALTER TABLE settings ADD COLUMN whatsapp_number TEXT DEFAULT NULL");
        echo "Added whatsapp_number column to settings table.\n";
    } else {
        echo "whatsapp_number column already exists in settings table.\n";
    }
    
    // Commit the transaction
    $db->commit();
    echo "Migration completed successfully.\n";
    
} catch (Exception $e) {
    // Roll back the transaction if something failed
    $db->rollBack();
    echo "Migration failed: " . $e->getMessage() . "\n";
    exit(1);
}
