<?php
require_once __DIR__ . '/../../config/db.php';

try {
    // Check if whatsapp_number column exists
    $stmt = $pdo->query("SHOW COLUMNS FROM settings LIKE 'whatsapp_number'");
    $columnExists = $stmt->rowCount() > 0;
    
    if (!$columnExists) {
        // Add whatsapp_number column
        $pdo->exec("ALTER TABLE settings ADD COLUMN whatsapp_number VARCHAR(20) DEFAULT NULL");
        echo "Added whatsapp_number column to settings table.\n";
        
        // Set a default value if needed
        $pdo->exec("UPDATE settings SET whatsapp_number = '8801712113295' WHERE id = 1");
        echo "Set default WhatsApp number.\n";
    } else {
        echo "whatsapp_number column already exists in settings table.\n";
    }
    
    echo "Migration completed successfully.\n";
    
} catch (PDOException $e) {
    echo "Migration failed: " . $e->getMessage() . "\n";
    exit(1);
}
