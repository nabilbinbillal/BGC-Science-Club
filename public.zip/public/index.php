<?php
session_start();
include 'config/db.php';
include 'includes/functions.php';

// Parse the URL path
$requestUri = $_SERVER['REQUEST_URI'];
$urlPath = parse_url($requestUri, PHP_URL_PATH);
$pathSegments = explode('/', trim($urlPath, '/'));

// Default page
$page = 'home';

// Handle dynamic URLs (case-insensitive)
if (count($pathSegments) > 0 && $pathSegments[0] !== '') {
    $segment = strtolower($pathSegments[0]);
    switch ($segment) {
        case 'executive':
            if (isset($pathSegments[1])) {
                $page = 'executive';
                $_GET['slug'] = $pathSegments[1];
            }
            break;
        case 'project':
            if (isset($pathSegments[1])) {
                $page = 'project';
                $_GET['slug'] = $pathSegments[1];
            } else {
                $page = 'projects';
            }
            break;
        case 'class':
            if (isset($pathSegments[1])) {
                $page = 'class';
                $_GET['slug'] = $pathSegments[1];
                if (isset($pathSegments[2])) {
                    $_GET['group'] = $pathSegments[2];
                }
            } else {
                $page = 'classes';
            }
            break;
        case 'department':
            if (isset($pathSegments[1])) {
                $page = 'department';
                $_GET['slug'] = $pathSegments[1];
            } else {
                $page = 'departments';
            }
            break;
        default:
            $validPages = ['about', 'executives', 'members', 'activities', 'events', 'join', 'about-developer', 'projects', 'classes', 'departments', 'logo'];
            if (in_array($segment, $validPages)) {
                $page = $segment;
            }
            break;
    }
} else {
    $page = isset($_GET['page']) ? $_GET['page'] : 'home';
}

// Initialize theme
$theme = isset($_COOKIE['theme']) ? $_COOKIE['theme'] : 
    (isset($_SERVER['HTTP_SEC_CH_PREFERS_COLOR_SCHEME']) && $_SERVER['HTTP_SEC_CH_PREFERS_COLOR_SCHEME'] === 'dark' ? 'dark' : 'light');

// Define allowed pages
$allowed_pages = [
    'home',
    'about',
    'members',
    'executives',
    'executive',
    'activities',
    'events',
    'join',
    'about-developer',
    'projects',
    'project',
    'classes',
    'class',
    'logo',
    'departments',
    'department'
];

// Ensure database connection is working
try {
    $pdo->query("SELECT 1");
} catch (PDOException $e) {
    die("Database connection failed. Please check your configuration.");
}
?>
<!DOCTYPE html>
<html lang="en" class="<?php echo $theme; ?>">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>BGC Science Club</title>
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link rel="stylesheet" href="assets/css/style.css">
    <script src="https://cdn.jsdelivr.net/npm/alpinejs@3.x.x/dist/cdn.min.js" defer></script>
</head>
<body class="font-poppins antialiased min-h-screen bg-gray-50 text-gray-800 dark:bg-gray-900 dark:text-gray-100 transition-colors duration-200">
    
    <?php include 'includes/header.php'; ?>
    
    <main>
        <?php
        // Include the page content
        if (in_array($page, $allowed_pages)) {
            include "pages/{$page}.php";
        } else {
            // 404 page
            header("HTTP/1.0 404 Not Found");
            include "404.php";
        }
        ?>
    </main>
    
    <?php include 'includes/footer.php'; ?>
    
    <script src="assets/js/script.js"></script>
</body>
</html>