-- Admin sessions table for "Remember Me" functionality
CREATE TABLE IF NOT EXISTS admin_sessions (
    id INT AUTO_INCREMENT PRIMARY KEY,
    admin_id INT NOT NULL,
    token VARCHAR(64) NOT NULL,
    expires DATETIME NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (admin_id) REFERENCES admins(id) ON DELETE CASCADE,
    UNIQUE KEY unique_token (token)
);

-- Add sort_order column to members and executives tables if not exists
ALTER TABLE members ADD COLUMN IF NOT EXISTS sort_order INT DEFAULT 0;
ALTER TABLE executives ADD COLUMN IF NOT EXISTS sort_order INT DEFAULT 0; 