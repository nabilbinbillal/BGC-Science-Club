<?php
require_once 'config/db.php';

$search_query = isset($_GET['q']) ? trim($_GET['q']) : '';
$results = [];
$total_results = 0;

if (!empty($search_query)) {
    // Sanitize search query
    $search_term = "%" . $search_query . "%";
    
    // Search in members
    $stmt = $pdo->prepare("SELECT 'member' as type, id, name, department, member_id, image FROM members 
                          WHERE name LIKE ? OR department LIKE ? OR member_id LIKE ? LIMIT 5");
    $stmt->execute([$search_term, $search_term, $search_term]);
    $results['members'] = $stmt->fetchAll();
    
    // Search in activities
    $stmt = $pdo->prepare("SELECT 'activity' as type, id, title, description, date FROM activities 
                          WHERE title LIKE ? OR description LIKE ? LIMIT 5");
    $stmt->execute([$search_term, $search_term]);
    $results['activities'] = $stmt->fetchAll();
    
    // Search in executives
    $stmt = $pdo->prepare("SELECT 'executive' as type, id, name, position, department, slug FROM executives 
                          WHERE name LIKE ? OR position LIKE ? OR department LIKE ? LIMIT 5");
    $stmt->execute([$search_term, $search_term, $search_term]);
    $results['executives'] = $stmt->fetchAll();
    
    // Calculate total results
    $total_results = count($results['members']) + count($results['activities']) + count($results['executives']);
}
?>

<?php include 'includes/header.php'; ?>
  
    <!-- Tailwind CSS -->
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
    
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    
    <!-- Custom Styles -->
    <link rel="stylesheet" href="/assets/css/style.css">
    <link href="/assets/css/carousel.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link rel="stylesheet" href="../assets/css/style.css">
    <link rel="stylesheet" href="../assets/css/style.css">

    
<div class="min-h-screen bg-gray-50 dark:bg-gray-900 py-12">
    <div class="container mx-auto px-4 sm:px-6 lg:px-8">
        <!-- Search Header -->
        <div class="max-w-3xl mx-auto mb-12">
            <h1 class="text-3xl font-bold text-gray-900 dark:text-white text-center mb-8">Search BGC Science Club</h1>
            
            <!-- Search Form -->
            <form action="/search" method="GET" class="flex gap-2">
                <div class="relative flex-1">
                    <input type="text" name="q" value="<?php echo htmlspecialchars($search_query); ?>" 
                           placeholder="Search for members, activities, events..." 
                           class="w-full px-4 py-3 rounded-lg border border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-800 text-gray-900 dark:text-white focus:ring-2 focus:ring-primary-500 focus:border-transparent">
                    <div class="absolute inset-y-0 right-0 flex items-center pr-3">
                        <svg class="w-5 h-5 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"/>
                        </svg>
                    </div>
                </div>
                <button type="submit" 
                    class="px-6 py-3 bg-primary-600 hover:bg-primary-700 text-white font-medium rounded-lg transition-colors">
                    Search
                </button>
            </form>
        </div>

        <?php if (!empty($search_query)): ?>
            <!-- Search Results -->
            <div class="max-w-4xl mx-auto">
                <?php if ($total_results > 0): ?>
                    <div class="text-gray-600 dark:text-gray-400 mb-8">
                        Found <?php echo $total_results; ?> results for "<?php echo htmlspecialchars($search_query); ?>"
                    </div>

                    <!-- Members Results -->
                    <?php if (!empty($results['members'])): ?>
                    <div class="mb-12">
                        <h2 class="text-xl font-semibold text-gray-900 dark:text-white mb-4">Members</h2>
                        <div class="grid gap-6 md:grid-cols-2">
                            <?php foreach ($results['members'] as $member): ?>
                            <div class="bg-white dark:bg-gray-800 rounded-lg shadow p-6 flex items-center space-x-4">
                                <div class="flex-shrink-0">
                                    <img src="<?php echo $member['image'] ? '/uploads/members/' . $member['image'] : '/assets/images/default-avatar.jpg'; ?>" 
                                         alt="<?php echo htmlspecialchars($member['name']); ?>"
                                         class="w-12 h-12 rounded-full object-cover">
                                </div>
                                <div>
                                    <h3 class="text-lg font-medium text-gray-900 dark:text-white">
                                        <?php echo htmlspecialchars($member['name']); ?>
                                    </h3>
                                    <p class="text-sm text-gray-500 dark:text-gray-400">
                                        <?php echo htmlspecialchars($member['department']); ?>
                                    </p>
                                </div>
                            </div>
                            <?php endforeach; ?>
                        </div>
                    </div>
                    <?php endif; ?>

                    <!-- Activities Results -->
                    <?php if (!empty($results['activities'])): ?>
                    <div class="mb-12">
                        <h2 class="text-xl font-semibold text-gray-900 dark:text-white mb-4">Activities & Events</h2>
                        <div class="space-y-6">
                            <?php foreach ($results['activities'] as $activity): ?>
                            <div class="bg-white dark:bg-gray-800 rounded-lg shadow p-6">
                                <h3 class="text-lg font-medium text-gray-900 dark:text-white mb-2">
                                    <?php echo htmlspecialchars($activity['title']); ?>
                                </h3>
                                <p class="text-sm text-gray-500 dark:text-gray-400 mb-2">
                                    <?php echo date('F j, Y', strtotime($activity['date'])); ?>
                                </p>
                                <p class="text-gray-600 dark:text-gray-300 line-clamp-2">
                                    <?php echo htmlspecialchars($activity['description']); ?>
                                </p>
                            </div>
                            <?php endforeach; ?>
                        </div>
                    </div>
                    <?php endif; ?>

                    <!-- Executives Results -->
                    <?php if (!empty($results['executives'])): ?>
                    <div class="mb-12">
                        <h2 class="text-xl font-semibold text-gray-900 dark:text-white mb-4">Executives</h2>
                        <div class="grid gap-6 md:grid-cols-2">
                            <?php foreach ($results['executives'] as $executive): ?>
                            <a href="/executive/<?php echo $executive['slug']; ?>" 
                               class="bg-white dark:bg-gray-800 rounded-lg shadow p-6 hover:shadow-lg transition-shadow">
                                <h3 class="text-lg font-medium text-gray-900 dark:text-white mb-1">
                                    <?php echo htmlspecialchars($executive['name']); ?>
                                </h3>
                                <p class="text-primary-600 dark:text-primary-400 font-medium mb-1">
                                    <?php echo htmlspecialchars($executive['position']); ?>
                                </p>
                                <p class="text-sm text-gray-500 dark:text-gray-400">
                                    <?php echo htmlspecialchars($executive['department']); ?>
                                </p>
                            </a>
                            <?php endforeach; ?>
                        </div>
                    </div>
                    <?php endif; ?>

                <?php else: ?>
                    <div class="text-center py-12">
                        <div class="mb-4">
                            <svg class="mx-auto h-12 w-12 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9.172 16.172a4 4 0 015.656 0M9 10h.01M15 10h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"/>
                            </svg>
                        </div>
                        <h3 class="text-lg font-medium text-gray-900 dark:text-white mb-2">No results found</h3>
                        <p class="text-gray-500 dark:text-gray-400">
                            Try adjusting your search or filter to find what you're looking for.
                        </p>
                    </div>
                <?php endif; ?>
            </div>
        <?php endif; ?>
    </div>
</div>

<?php include 'includes/footer.php'; ?> 