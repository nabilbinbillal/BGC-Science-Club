<?php
$classOptions = getClassOptions(true);
$classNames = array_column($classOptions, 'name');
$departmentOptions = getDepartmentOptions();

$search = trim($_GET['search'] ?? '');
$classFilter = trim($_GET['class'] ?? '');
$departmentFilter = trim($_GET['department'] ?? '');
$memberFilter = strtoupper(trim($_GET['member_id'] ?? ''));
$collaborativeOnly = isset($_GET['collaborative']) && $_GET['collaborative'] === '1';

$stmt = $pdo->query("SELECT * FROM projects ORDER BY date DESC");
$projects = array_map(function ($project) {
    return normalizeProjectRecord($project);
}, $stmt->fetchAll());

$filteredProjects = array_filter($projects, function ($project) use ($search, $classFilter, $departmentFilter, $memberFilter, $collaborativeOnly) {
    if ($search) {
        $haystack = strtolower($project['title'] . ' ' . ($project['short_description'] ?? '') . ' ' . ($project['long_description'] ?? ''));
        if (strpos($haystack, strtolower($search)) === false) {
            return false;
        }
    }
    if ($classFilter && !in_array($classFilter, $project['class_scope'])) {
        return false;
    }
    if ($departmentFilter && !in_array($departmentFilter, $project['department_scope'])) {
        return false;
    }
    if ($collaborativeOnly && !$project['is_collaborative']) {
        return false;
    }
    if ($memberFilter) {
        $matchedIds = array_map('strtoupper', $project['contributor_ids']);
        if (!in_array($memberFilter, $matchedIds)) {
            return false;
        }
    }
    return true;
});
?>
<section class="bg-gray-100 py-8">
    <div class="container mx-auto px-4">
        <h1 class="text-4xl font-bold text-gray-800 mb-4">Projects</h1>
        <p class="text-gray-600 max-w-2xl">Dive into scientific explorations contributed by Intermediate classes, science departments, and collaborative club teams.</p>
    </div>
</section>

<section class="py-12 bg-white dark:bg-gray-900 transition-colors duration-200">
    <div class="container mx-auto px-4 sm:px-6 lg:px-8">
        <form method="GET" class="bg-gray-50 dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-2xl p-6 mb-10 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            <div>
                <label class="block text-sm font-semibold text-gray-700 dark:text-gray-300 mb-2">Search</label>
                <input type="text" name="search" value="<?php echo htmlspecialchars($search); ?>" placeholder="Project title or keyword" class="w-full px-4 py-2 border rounded-md text-gray-700 dark:bg-gray-900 dark:border-gray-700 dark:text-white">
            </div>
            <div>
                <label class="block text-sm font-semibold text-gray-700 dark:text-gray-300 mb-2">Class</label>
                <select name="class" class="w-full px-4 py-2 border rounded-md text-gray-700 dark:bg-gray-900 dark:border-gray-700 dark:text-white">
                    <option value="">All Classes</option>
                    <?php foreach ($classNames as $class): ?>
                        <option value="<?php echo htmlspecialchars($class); ?>" <?php echo $classFilter === $class ? 'selected' : ''; ?>>
                            <?php echo htmlspecialchars($class); ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div>
                <label class="block text-sm font-semibold text-gray-700 dark:text-gray-300 mb-2">Department</label>
                <select name="department" class="w-full px-4 py-2 border rounded-md text-gray-700 dark:bg-gray-900 dark:border-gray-700 dark:text-white">
                    <option value="">All Departments</option>
                    <?php foreach ($departmentOptions as $dept): ?>
                        <option value="<?php echo htmlspecialchars($dept); ?>" <?php echo $departmentFilter === $dept ? 'selected' : ''; ?>>
                            <?php echo htmlspecialchars($dept); ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div>
                <label class="block text-sm font-semibold text-gray-700 dark:text-gray-300 mb-2">Member ID</label>
                <input type="text" name="member_id" value="<?php echo htmlspecialchars($memberFilter); ?>" placeholder="BGC-24-0001" class="w-full px-4 py-2 border rounded-md text-gray-700 dark:bg-gray-900 dark:border-gray-700 dark:text-white uppercase">
            </div>
            <div class="flex items-center space-x-2">
                <input type="checkbox" id="collaborative" name="collaborative" value="1" class="h-4 w-4 text-primary-500" <?php echo $collaborativeOnly ? 'checked' : ''; ?>>
                <label for="collaborative" class="text-sm text-gray-700 dark:text-gray-300 font-semibold">Club-wide only</label>
            </div>
            <div class="md:col-span-2 lg:col-span-4 flex flex-wrap gap-4 mt-4">
                <button type="submit" class="px-6 py-2 bg-primary-500 hover:bg-primary-600 text-white font-semibold rounded-md transition">Apply Filters</button>
                <a href="/projects" class="px-6 py-2 border border-gray-300 hover:border-primary-500 text-gray-700 hover:text-primary-500 rounded-md transition">Reset</a>
            </div>
        </form>

        <p class="text-sm text-gray-500 dark:text-gray-400 mb-6"><?php echo count($filteredProjects); ?> project(s) found.</p>

        <?php if (!empty($filteredProjects)): ?>
            <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
                <?php foreach ($filteredProjects as $project): 
                    $imageSrc = !empty($project['image']) ? '/uploads/projects/' . htmlspecialchars($project['image']) : 'https://images.pexels.com/photos/271667/pexels-photo-271667.jpeg';
                ?>
                    <article class="bg-gray-50 dark:bg-gray-800 rounded-2xl shadow hover:shadow-xl transition overflow-hidden flex flex-col">
                        <img src="<?php echo $imageSrc; ?>" alt="<?php echo htmlspecialchars($project['title']); ?>" class="w-full h-40 object-cover">
                        <div class="p-6 flex flex-col flex-grow">
                            <p class="text-xs uppercase tracking-wide text-primary-500 font-semibold mb-2"><?php echo formatDate($project['date']); ?></p>
                            <h3 class="text-xl font-semibold text-gray-900 dark:text-white mb-2"><?php echo htmlspecialchars($project['title']); ?></h3>
                            <?php
                            $projectSummarySource = $project['short_description'] ?: ($project['description'] ?? '');
                            $projectSummary = $projectSummarySource;
                            if (!$project['short_description'] && strlen($projectSummarySource) > 140) {
                                $projectSummary = substr($projectSummarySource, 0, 140) . '...';
                            }
                            ?>
                            <p class="text-gray-600 dark:text-gray-300 mb-4 flex-grow"><?php echo htmlspecialchars($projectSummary); ?></p>
                            <div class="flex flex-wrap gap-2 mb-4">
                                <?php foreach ($project['class_scope'] as $classTag): ?>
                                    <span class="px-3 py-1 bg-white dark:bg-gray-900 border border-gray-200 dark:border-gray-700 rounded-full text-xs text-gray-700 dark:text-gray-300"><?php echo htmlspecialchars($classTag); ?></span>
                                <?php endforeach; ?>
                                <?php foreach ($project['department_scope'] as $deptTag): ?>
                                    <span class="px-3 py-1 bg-white dark:bg-gray-900 border border-gray-200 dark:border-gray-700 rounded-full text-xs text-gray-700 dark:text-gray-300"><?php echo htmlspecialchars($deptTag); ?></span>
                                <?php endforeach; ?>
                                <?php if ($project['is_collaborative']): ?>
                                    <span class="px-3 py-1 bg-green-100 text-green-700 rounded-full text-xs font-semibold">Club-wide</span>
                                <?php endif; ?>
                            </div>
                            <div class="flex items-center justify-between text-sm text-gray-500 dark:text-gray-400">
                                <span><?php $count = count($project['contributor_ids']); echo $count ? $count . ' contributor' . ($count > 1 ? 's' : '') : 'Open call'; ?></span>
                                <a href="/project/<?php echo htmlspecialchars($project['slug']); ?>" class="text-primary-500 hover:text-primary-600 font-semibold">View details →</a>
                            </div>
                        </div>
                    </article>
                <?php endforeach; ?>
            </div>
        <?php else: ?>
            <div class="bg-gray-50 dark:bg-gray-800 border border-dashed border-gray-200 dark:border-gray-700 rounded-2xl p-12 text-center">
                <h3 class="text-xl font-semibold text-gray-900 dark:text-white mb-2">No projects found</h3>
                <p class="text-gray-600 dark:text-gray-400">Try adjusting your filters or search keyword.</p>
            </div>
        <?php endif; ?>
    </div>
</section>

