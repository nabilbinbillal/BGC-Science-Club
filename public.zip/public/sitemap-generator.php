<?php
header('Content-Type: application/xml; charset=utf-8');

require_once __DIR__ . '/config/db.php';

echo '<?xml version="1.0" encoding="UTF-8"?>' . "\n";
echo '<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">' . "\n";

// Add homepage
echo "<url>\n";
echo "<loc>http://" . $_SERVER['HTTP_HOST'] . "/</loc>\n";
echo "<changefreq>daily</changefreq>\n";
echo "<priority>1.0</priority>\n";
echo "</url>\n";

// Add executives main page
echo "<url>\n";
echo "<loc>http://" . $_SERVER['HTTP_HOST'] . "/executives</loc>\n";
echo "<changefreq>weekly</changefreq>\n";
echo "<priority>0.8</priority>\n";
echo "</url>\n";

// Add executives archive pages
$stmt = $pdo->query("SELECT DISTINCT archive_year FROM executives WHERE archive_year IS NOT NULL ORDER BY archive_year DESC");
$archiveYears = $stmt->fetchAll(PDO::FETCH_COLUMN);

foreach ($archiveYears as $year) {
    echo "<url>\n";
    echo "<loc>http://" . $_SERVER['HTTP_HOST'] . "/executives-year.php?year=" . urlencode($year) . "</loc>\n";
    echo "<changefreq>monthly</changefreq>\n";
    echo "<priority>0.6</priority>\n";
    echo "</url>\n";
}

// Add other URLs as needed...

echo '</urlset>';
?>
