<?php
// This script outputs PHP configuration info including loaded php.ini and enabled extensions
phpinfo();
?>
