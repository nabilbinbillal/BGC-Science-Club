/*
  # Initial Schema Setup for BGC Science Club

  1. New Tables
    - `admins`: Stores admin user information and access levels
      - `id` (uuid, primary key)
      - `username` (text, unique)
      - `password` (text)
      - `name` (text)
      - `email` (text)
      - `role` (text)
      - `created_at` (timestamp)
    c
    - `members`: Stores club member information
      - `id` (uuid, primary key)
      - `name` (text)
      - `department` (text)
      - `role` (text)
      - `joining_date` (date)
      - `roll_no` (text)
      - `member_id` (text, unique)
      - `status` (text)
      - `image` (text)
      - `gender` (text)
      - `position` (text)
      - `email` (text)
      - `phone` (text)
      - `created_at` (timestamp)
    
    - `activities`: Stores club activities and events
      - `id` (uuid, primary key)
      - `title` (text)
      - `description` (text)
      - `image` (text)
      - `date` (date)
      - `created_at` (timestamp)

  2. Security
    - Enable RLS on all tables
    - Add policies for authenticated users
*/

-- Create admins table
CREATE TABLE IF NOT EXISTS admins (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  username text UNIQUE NOT NULL,
  password text NOT NULL,
  name text NOT NULL,
  email text NOT NULL,
  role text NOT NULL DEFAULT 'admin',
  created_at timestamptz DEFAULT now()
);

-- Create members table
CREATE TABLE IF NOT EXISTS members (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  department text NOT NULL,
  role text NOT NULL DEFAULT 'member',
  joining_date date NOT NULL DEFAULT CURRENT_DATE,
  roll_no text,
  member_id text UNIQUE NOT NULL,
  status text DEFAULT 'pending',
  image text,
  gender text DEFAULT 'male',
  position text,
  email text,
  phone text,
  created_at timestamptz DEFAULT now()
);

-- Create activities table
CREATE TABLE IF NOT EXISTS activities (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  title text NOT NULL,
  description text NOT NULL,
  image text,
  date date NOT NULL,
  created_at timestamptz DEFAULT now()
);

-- Enable Row Level Security
ALTER TABLE admins ENABLE ROW LEVEL SECURITY;
ALTER TABLE members ENABLE ROW LEVEL SECURITY;
ALTER TABLE activities ENABLE ROW LEVEL SECURITY;

-- Create policies for admins table
CREATE POLICY "Admins can view own data" ON admins
  FOR SELECT TO authenticated
  USING (auth.uid() = id);

CREATE POLICY "Superadmins can manage all admins" ON admins
  FOR ALL TO authenticated
  USING (EXISTS (
    SELECT 1 FROM admins 
    WHERE id = auth.uid() 
    AND role = 'superadmin'
  ));

-- Create policies for members table
CREATE POLICY "Anyone can view approved members" ON members
  FOR SELECT
  USING (status = 'approved');

CREATE POLICY "Admins can manage members" ON members
  FOR ALL TO authenticated
  USING (EXISTS (
    SELECT 1 FROM admins 
    WHERE id = auth.uid()
  ));

-- Create policies for activities table
CREATE POLICY "Anyone can view activities" ON activities
  FOR SELECT
  USING (true);

CREATE POLICY "Admins can manage activities" ON activities
  FOR ALL TO authenticated
  USING (EXISTS (
    SELECT 1 FROM admins 
    WHERE id = auth.uid()
  ));

-- Insert default superadmin
INSERT INTO admins (username, password, name, email, role)
VALUES (
  'admin',
  crypt('admin', gen_salt('bf')),
  'Super Admin',
  'admin@bgcscienceclub.com',
  'superadmin'
) ON CONFLICT (username) DO NOTHING;